<?php
require('commun/codeconn.php');
require('commun/codeca.php');


?>

<?php
 

 
$_POST['m']=trim($_POST['m']);
if($_POST['submit1']&&$_POST['m']){

 
//防止数据恶意注入**************************************************
function check_input($value)
{
 if (get_magic_quotes_gpc())
  {
  $value = stripslashes($value);
  }
  
  $value = mysql_real_escape_string($value);
  
 
return $value;
}
//**************************************************



$m=check_input($_POST['m']);
$message='';

if(is_numeric($m)){



if(strlen($m)>=2){

$codepo=$m;
$suju_codepo='<tr><td>Ville</td><td>Code postal</td><td>Département</td><td>Région</td></tr>';


 
 
$query_sql = "SELECT id_ville,nom,id_departement,cp FROM ville  WHERE cp  like '$codepo%'  ORDER BY nom LIMIT 70";
$result = mysql_query($query_sql);
if(!$result) exit('fail&nbsp;'.mysql_error());

$nombre_ville[]='';

 while($gb_array = mysql_fetch_array($result)){
 $nombre_ville[]=$gb_array['nom'];

$codepo=$gb_array['cp'];
$ville_nom=$gb_array['nom'];
$id_ville=$gb_array['id_ville'];
$code=$gb_array['id_departement'];

if($id_ville)$ville_chk=TRUE;else $ville_chk=false;

//departement*************************************************



 


$de_sql = "SELECT * FROM departement WHERE code like '$code' ";
$de_result = mysql_query($de_sql);
if(!$de_result) exit('fail&nbsp;'.mysql_error());
$de_array = mysql_fetch_array($de_result);
 $departement=$arr_suzu[$de_array['daima']];

//region**************************************
$code_re=$de_array['id_region'];
$re_sql = "SELECT * FROM region WHERE id_region = '$code_re' ";
$re_result = mysql_query($re_sql);
if(!$re_result) exit('fail&nbsp;'.mysql_error());
$re_array = mysql_fetch_array($re_result);
$region=$arr_suzu[$re_array['daima']];
//************************************
$suju_titre='';
$suju_codepo.='<tr><td><strong style="border-bottom:#CCCCCC 1px solid;"><a href="ville.php?v='.$ville_nom.'&c='.$codepo.'&d='.$code.'#ville-ex" class="a2" >'.$ville_nom.'</a></strong></td><td>'.$codepo.'</td><td><strong style="border-bottom:#CCCCCC 1px solid;"><a href="departement.php?d='.$code.'" class="a2" >'.$departement.'</strong></td><td>'.$region.'</td></tr>';


}$nombre_ville=count($nombre_ville)-1;


if(!$ville_chk)$message="Aucune ville correspondant à votre recherche n'a été trouvée.";//没有找到城市

}else {$message="Veuillez saisir au moins 3 chiffres!";}


}else{//输入字母时



if(strlen($m)>=2){


$suju_codepo='<tr><td>Ville</td><td>Code postal</td><td>Département</td><td>Région</td></tr>';


//输入城市时*******************************
$ville=strtolower($m);
$ville=str_replace("-"," ",$ville);
$ville=str_replace("_"," ",$ville);
$ville=str_replace("　"," ",$ville);
  
$ville=preg_replace("#\bste\b#","saint",$ville);
$ville=preg_replace("#\bst\b#","saint",$ville);
$ville=preg_replace("#\bsainte\b#","saint",$ville);



$ville=preg_replace("#\s{2,}#"," ",$ville);
 
$ville=explode(" ",$ville);
$ville_mot0='';
$ville_mot='';

for($i=0;$i<=count($ville)-1;$i++){
$mot=$ville[$i];

if(preg_match("#oe#",$mot)){
	$ville_oe1=str_replace("oe","œ",$mot);
    if($i==0)$ville_mot0.=" AND (nom like '$mot%' OR nom like '$ville_oe1%') ";else $ville_mot0.=" AND (nom like '%$mot%' OR nom like '%$ville_oe1%') ";
    $ville_mot.=" AND (nom like '%$mot%' OR nom like '%$ville_oe1%') ";
	}
	elseif(preg_match("#œ#",$mot)){
	$ville_oe2=str_replace("œ","oe",$mot);
    if($i==0)$ville_mot0.=" AND (nom like '$mot%' OR nom like '$ville_oe1%') ";else $ville_mot0.=" AND (nom like '%$mot%' OR nom like '%$ville_oe1%') ";
    $ville_mot.=" AND (nom like '%$mot%' OR nom like '%$ville_oe2%') ";
	}else {
		if($i==0)$ville_mot0.=" AND nom like '$mot%' ";else $ville_mot0.=" AND nom like '%$mot%' ";
		$ville_mot.=" AND nom like '%$mot%' ";
		}
 



}

$nombre_ville[]='';
 

//用$mot%搜索**************************************************************************************************
//****************************************************************************************

$query_sql0 = "SELECT id_ville,nom, cp,id_departement FROM ville  WHERE 1 $ville_mot0 ORDER BY nom,cp LIMIT 70";
$result0 = mysql_query($query_sql0);
if(!$result0) exit('fail&nbsp;'.mysql_error());


 while($gb_array0 = mysql_fetch_array($result0)){
 	 
 $nombre_ville[]=$gb_array0['nom'];

$codepo0=$gb_array0['cp'];
$ville_nom0=$gb_array0['nom'];
$id_ville0=$gb_array0['id_ville'];

$code0=$gb_array0['id_departement'];
$id_non[]=$gb_array0['id_ville'];
if($id_ville0)$ville_chk=TRUE;else $ville_chk=false;

//departement*************************************************
//********************************************************************************************
//********************************************************************************************

 $de_sql0 = "SELECT * FROM departement WHERE code like '$code0' ";
$de_result0= mysql_query($de_sql0);
if(!$de_result0) exit('fail&nbsp;'.mysql_error());
$de_array0 = mysql_fetch_array($de_result0);
$departement0=$arr_suzu[$de_array0['daima']];
//region**************************************
//********************************************************************************************
//********************************************************************************************

$code_re0=$de_array0['id_region'];
$re_sql0 = "SELECT * FROM region WHERE id_region = '$code_re0' ";
$re_result0 = mysql_query($re_sql0);
if(!$re_result0) exit('fail&nbsp;'.mysql_error());
$re_array0 = mysql_fetch_array($re_result0);
$region0=$arr_suzu[$re_array0['daima']];
//********************************************************************************************
//********************************************************************************************


$suju_titre='';
$suju_codepo.='<tr><td><strong style="border-bottom:#CCCCCC 1px solid;"><a href="ville.php?v='.$ville_nom0.'&c='.$codepo0.'&d='.$code0.'#ville-ex" class="a2" >'.$ville_nom0.'</a></strong></td><td>'.$codepo0.'</td><td><strong style="border-bottom:#CCCCCC 1px solid;"><a href="departement.php?d='.$code0.'" class="a2" >'.$departement0.'</strong></td><td>'.$region0.'</td></tr>';







	 }
	 
	
//用%$mot%搜索**************************************************************************************************
//****************************************************************************************
   $id_non_sql='';if($id_non) $id_non_sql=" AND id_ville NOT IN ('".implode("','",$id_non)."') ";
$query_sql = "SELECT id_ville,nom, cp,id_departement FROM ville  WHERE 1 $ville_mot $id_non_sql ORDER BY nom,cp LIMIT 70";
$result = mysql_query($query_sql);
if(!$result) exit('fail&nbsp;'.mysql_error());


 while($gb_array = mysql_fetch_array($result)){
 $nombre_ville[]=$gb_array['nom'];

$codepo=$gb_array['cp'];
$ville_nom=$gb_array['nom'];
$id_ville=$gb_array['id_ville'];

$code=$gb_array['id_departement'];
if($id_ville)$ville_chk=TRUE;else $ville_chk=false;

//departement*************************************************
//********************************************************************************************
//********************************************************************************************

 $de_sql = "SELECT * FROM departement WHERE code like '$code' ";
$de_result = mysql_query($de_sql);
if(!$de_result) exit('fail&nbsp;'.mysql_error());
$de_array = mysql_fetch_array($de_result);
 $departement=$arr_suzu[$de_array['daima']];
//region**************************************
//********************************************************************************************
//********************************************************************************************

$code_re=$de_array['id_region'];
$re_sql = "SELECT * FROM region WHERE id_region = '$code_re' ";
$re_result = mysql_query($re_sql);
if(!$re_result) exit('fail&nbsp;'.mysql_error());
$re_array = mysql_fetch_array($re_result);
$region=$arr_suzu[$re_array['daima']];
//********************************************************************************************
//********************************************************************************************


$suju_titre='';
$suju_codepo.='<tr><td><strong style="border-bottom:#CCCCCC 1px solid;"><a href="ville.php?v='.$ville_nom.'&c='.$codepo.'&d='.$code.'#ville-ex" class="a2" >'.$ville_nom.'</a></strong></td><td>'.$codepo.'</td><td><strong style="border-bottom:#CCCCCC 1px solid;"><a href="departement.php?d='.$code.'" class="a2" >'.$departement.'</strong></td><td>'.$region.'</td></tr>';


}
//*************************************************************
//*************************************************************
//************************************************************* 

$nombre_ville=count($nombre_ville)-1;


if(!$ville_chk)$message="Aucune ville correspondant à votre recherche n'a été trouvée.";//没有找到城市

}else {$message="Veuillez saisir au moins 3 lettres!";}


}

 







}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" 
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta http-equiv="content-language"		content="fr"			/>
<meta name="copyright"		content="http://code-postal-fr.net" />
<meta name="classification"	content="code postal,codes postaux,courrier,poste" />

<meta name="content"		content="Code postal villes : cherchez le code postal d'une ville ou l'inverse parmi 36000 villes et trouvez aussi des suggestions de sites internet locaux (entreprises, loisirs, tourisme, etc.) ainsi qu'une carte de chaque ville." />
    
<meta name="description" content="Code postal villes : cherchez le code postal d'une ville ou l'inverse parmi 36000 villes et trouvez aussi des suggestions de sites internet locaux (entreprises, loisirs, tourisme, etc.) ainsi qu'une carte de chaque ville." />	 
	<meta name="expires"		content="never" />
      
<meta name="keywords" content="codespostaux, codes, postaux, code, postal, recherche, ville, france, rechercher, info, fr, departement, departements, gratuit, service, rechercher, codepostal, code-postal, codes-postaux, code postal, codes postaux, ville francaise" />
<title>Code postal 
<?php 
if($codepo)echo '-',$codepo," ";
if($departement)echo $departement," ";
if($region)echo $region," ";
?> Tous les codes postaux de France</title>
 
<link href="css.css" rel="stylesheet" type="text/css" />
<style type="text/css">
 @import url("webfonts/Sansation_Regular/stylesheet.css");

</style>
</head>

<body>
<?php require("head.php");?>



<div style="padding:15px;" class="style2">

 <strong style=" font-family: 'Trebuchet MS', Arial, Helvetica, sans-serif; font-size:36px">Code postal des villes françaises</strong><br />
 <br />

<div style="font-size:12px">
<fieldset style=" padding:20px;border:1px solid #f00;" >
<legend>Cherchez le code postal d'une ville ou la ville pour un code postal</legend>
<br />
<br />

<form  id="form1" name="form1" method="post" action=""  >
    <strong>Votre recherche :</strong> <input name="m"  class="input"    type="text"  value="<?php if($_POST['m']) echo $_POST['m']?>"  size="30"/> <input name="submit1" value="Chercher"  type="submit"    class="tijiaoanniuziti"/>  
      
    
    </form> 
 
<div><?php
 if($message){
 ?><br />

   <div  style=" border:#c62323; 1px dashed; background-color: #FFBFBF; padding:5px; ">
<strong style="color:#c62323"><?=$message?></strong></div>
<?php
}else{ 
if($_POST['submit1']&&$_POST['m']){
echo '
<br />

<div  style=" border:#FFBFBF 1px dashed; background-color: #FFBFBF; padding:5px;">
<table cellspacing="5"><tbody>';
 echo $suju_titre.$suju_codepo;
 if($nombre_ville>1)$nombre_ville=$nombre_ville.' villes';else $nombre_ville=$nombre_ville.' ville';

echo "</tbody></table>
<br />
<div>  <strong>$nombre_ville correspondent à votre recherche.</strong></div>
</div>";}
}?>
</div></fieldset>
<br />
  
 
  
 
</div>
</div>
 

</div>
  <br />
<br />
<?php require("foot.php");?>
</body>
</html>