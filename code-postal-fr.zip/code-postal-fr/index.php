<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" 
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta http-equiv="content-language"		content="fr"			/>
<meta name="copyright"		content="http://code-postal-fr.net" />
<meta name="classification"	content="code postal,codes postaux,courrier,poste" />

<meta name="content"		content="Code postal villes : cherchez le code postal d'une ville ou l'inverse parmi 36000 villes et trouvez aussi des suggestions de sites internet locaux (entreprises, loisirs, tourisme, etc.) ainsi qu'une carte de chaque ville." />
    
<meta name="description" content="Code postal villes : cherchez le code postal d'une ville ou l'inverse parmi 36000 villes et trouvez aussi des suggestions de sites internet locaux (entreprises, loisirs, tourisme, etc.) ainsi qu'une carte de chaque ville." />	 
	<meta name="expires"		content="never" />
      
<meta name="keywords" content="codespostaux, codes, postaux, code, postal, recherche, ville, france, rechercher, info, fr, departement, departements, gratuit, service, rechercher, codepostal, code-postal, codes-postaux, code postal, codes postaux, ville francaise" />


<title>Code postal . Tous les codes postaux de France</title>
 
<link href="css.css" rel="stylesheet" type="text/css" />

<style type="text/css">
 @import url("webfonts/Sansation_Regular/stylesheet.css");

</style>
</head>

<body>
<?php require("head.php");?>


<div style="padding:15px;" class="style2">

 <strong style=" font-family: 'Trebuchet MS', Arial, Helvetica, sans-serif; font-size:36px">Code postal des villes françaises</strong><br />
 <br />

<div style="font-size:12px">
<fieldset style=" padding:20px;border:1px solid #f00;" >
<legend>Cherchez le code postal d'une ville ou la ville pour un code postal</legend>
<strong><br />
<br />
<form  id="form1" name="form1" method="post" action="recherche.php"  >
  <strong>Votre recherche :</strong><input name="m"  class="input"    type="text"  value="<?php if($_POST['m']) echo $_POST['m']?>"  size="30"/> <input name="submit1" value="Chercher"  type="submit"    class="tijiaoanniuziti"/>  
      
    
  </form><br />
<br />
- Pour trouver un code postal :</strong> saisissez quelques lettres du nom de la ville française dont vous cherchez le code postal. <strong>Vous devez saisir au moins 2 lettres du nom de la ville</strong> recherchée.<br />
<br />
<strong>- Pour trouver le nom d'une ville :</strong> saisissez <strong>au moins les 2 premiers caractères du code postal</strong> pour lequel vous souhaitez connaître la ville.<br />
<br />
 
 
</fieldset>
<br />
<div style="padding:5px">Code-Postal-fr.net : Recherchez gratuitement des codes postaux ou des départements parmis les plus de 36 000 communes répertoriées dans notre base de données !</div>
</div>
 

</div>
 
 <br />
<br />
<?php require("foot.php");?>
</body>
</html>