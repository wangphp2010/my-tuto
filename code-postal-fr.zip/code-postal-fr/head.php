<div id="accueil"  class="border-b">
<div><a href="http://code-postal-fr.net/"><img src="image/logo.png" width="190" height="90" /></a></div>
<table align="center"><tbody><tr>
<td class="style1"><a href="/" class="ah">Accueil</a></td>
<td class="style1"><a href="/departement.php" class="ah">Département</a></td>
<td class="style1"><a href="/ville.php" class="ah">Ville</a></td>
<td class="style1"><a href="/contact.php" class="ah">Contact</a></td></tr></tbody></table></div>
<br />
<div align="center">
<br />

<div style="border:#000 solid 1px;height:80px ; width:728px; padding:10px;" ><table border="0" cellpadding="0" cellspacing="0" align="center">
   
  <tr>
    <td     align="center" ><a href="http://monpub.com/" class="a1"><strong>MonPub.com</strong><br />
Site de petites annonces gratuites pour tout acheter, louer et vendre. Passer une petite annonce gratuitement ou rechercher des petites annonces immobilieres, voiture occasion, moto, offres d'emploi, animaux, services...</a></td>
   
  </tr>
</table>
</div><br /><br />
 

<div align="center"><div  style="border:#000 solid 1px; height:90px ; width:728px">
 
 

<script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
 <ins class="adsbygoogle"
     style="display:inline-block;width:728px;height:90px"
     data-ad-client="ca-pub-6001819914727980"
     data-ad-slot="4439952133"></ins>
<script>
(adsbygoogle = window.adsbygoogle || []).push({});
</script> 
</div></div>
 



</div>
<br /> 
 