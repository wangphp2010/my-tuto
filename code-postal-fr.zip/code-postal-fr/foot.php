<div align="center">
 <div style="position:fixed;bottom:0px; margin-left:86px; z-index:999; width:745px;"> 

 <a class="a3"  href="//monpub.com/rechercheregion.php?p=1&ca=6&re=100&de=117&of=219codepo=<?=$codepo?>" style="margin-bottom:1px; font-size:20px;"><strong style="border:1px solid #000; background-color:#FFF">Petites annonces <?php if($ville) echo "de $ville"; if($codepo)echo "($codepo)";?></strong></a><br />
 
  <div onclick="fermer_foot_pub(this)" class="sup" style="float:right;width:15px;height:15px; background-color:#666; " >×</div>
  
  <div>

<?php if($pasdeadfoot!='1'){?>
 
<script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<!-- foot --> 
<ins class="adsbygoogle"
     style="display:inline-block;width:728px;height:90px;border:#000 solid 1px;"
     data-ad-client="ca-pub-6001819914727980"
     data-ad-slot="6251562578"></ins>
<script>
(adsbygoogle = window.adsbygoogle || []).push({});
</script> 
<?php }?>

</div>
</div></div>
 <script src="http://monpub.com/jquery.min.js"></script>

 
  <script>function fermer_foot_pub(id){
    $(id).parent().animate({opacity:0,bottom:"-100"},500,function(){
		 	 $(id).parent().css({"position":"","height":"0px"}); 
 		 	 $(id).css("display","none"); 
      $(id).parent().animate({"height":"90px","opacity":"1" });
		 });
		 
	 }
	 </script>





 




<br /><br />
<div align="center" class="border-t" style="padding:10px;padding-bottom:150px"><a href="http://code-postal-fr.net/departement.php" class="a1">Recherche par département </a>  |  <a href="http://code-postal-fr.net/ville.php" class="a1">Recherche par ville </a> <br />
<br>
<a href="http://monpub.com" class="a1">annonce gratuit vente commerce</a>  
<a href="http://www.coodoeil.fr/P-201801-0-B1-code-postal-tous-les-codes-postaux-de-france.html" class="a1">coodoeil</a> 

  <br><br />
  © 2014 Code-Postal-Fr.net - Tous droits réservés</div>
