<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<?php



$villea="
Aiglun  
Allemagne-en-Provence  
Allons  
Allos  
Angles  
Annot  
Volx   ";
 
$villea=trim($villea);
$arr_villea= explode("\n",$villea);

foreach($arr_villea as $value){
	$value=trim($value);
	$value=str_replace("-"," ",$value);
$value=str_replace("_"," ",$value);
$value=str_replace("　","",$value);
$value=strtolower($value);

}

 
$villeb="
asfsadfsdf
asdfasdfsdf
asdfsdf
Allemagne-en-Provence 
Allons  
Allos  
Angles  
Annot  
Volx

 
";
$villeb=trim($villeb);
$arr_villeb= explode("\n",$villeb);

foreach($arr_villeb as $value){
	$value=trim($value);
	$value=str_replace("-"," ",$value);
$value=str_replace("_"," ",$value);
$value=str_replace("　","",$value);
$value=strtolower($value);
}

$numa=count($arr_villea);


echo "我们没有的城市<br>";

for($i=0;$i<$numa;$i++){
    if(!in_array($arr_villea[$i],$arr_villeb))	
      echo $arr_villea[$i],"<br>";
	}
 
 echo "<br />
<br />
****************************************************************<br />
<br />

";



echo "他们没有的城市<br />
";
$numb=count($arr_villeb);

for($t=0;$t<$numb;$t++){
 if(!in_array($arr_villeb[$t],$arr_villea))
 echo $arr_villeb[$t],"<br>";
	} 
	
	
	
?>