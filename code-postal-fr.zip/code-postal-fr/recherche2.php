<?php
require('commun/codeconn.php');
require('commun/codeca.php');


?>

<?php
 

 
$_POST['m']=trim($_POST['m']);
if($_POST['submit1']&&$_POST['m']){

 
//防止数据恶意注入**************************************************
function check_input($value)
{
 if (get_magic_quotes_gpc())
  {
  $value = stripslashes($value);
  }
  
  $value = mysql_real_escape_string($value);
  
 
return $value;
}
//**************************************************



$m=check_input($_POST['m']);
$message='';

if(is_numeric($m)){



if(strlen($m)>=3){

$codepo=$m;
$suju_codepo='<tr><td class="style5">Ville</td><td class="style5">Code postal</td><td class="style5">Département</td><td class="style5">Région</td></tr>
<tr><td></td><td></td><td></td><td></td></tr>';


 
 
$query_sql = "SELECT nom,id_departement,cp FROM ville  WHERE cp  like '$codepo%'  ORDER BY nom ";
$result = mysql_query($query_sql);
if(!$result) exit('fail&nbsp;'.mysql_error());

$nombre_ville[]='';

 while($gb_array = mysql_fetch_array($result)){
 $nombre_ville[]=$gb_array['nom'];

$codepo=$gb_array['cp'];
$ville_nom=$gb_array['nom'];
$code=$gb_array['id_departement'];

if($ville_nom)$ville_chk=TRUE;else $ville_chk=false;

//departement*************************************************



 


$de_sql = "SELECT * FROM departement WHERE code like '$code' ";
$de_result = mysql_query($de_sql);
if(!$de_result) exit('fail&nbsp;'.mysql_error());
$de_array = mysql_fetch_array($de_result);
 $departement=$arr_suzu[$de_array['daima']];

//region**************************************
$code_re=$de_array['id_region'];
$re_sql = "SELECT * FROM region WHERE id_region = '$code_re' ";
$re_result = mysql_query($re_sql);
if(!$re_result) exit('fail&nbsp;'.mysql_error());
$re_array = mysql_fetch_array($re_result);
$region=$arr_suzu[$re_array['daima']];
//************************************
$suju_titre='';
$suju_codepo.='<tr><td><strong style="border-bottom:#CCCCCC 1px solid;"><a href="ville.php?v='.$ville_nom.'&c='.$codepo.'&d='.$code.'"  class="a4"  >'.$ville_nom.'</a></strong></td><td class="style4">'.$codepo.'</td><td><strong style="border-bottom:#CCCCCC 1px solid;"><a href="departement.php?d='.$code.'"   class="a4" >'.$departement.'</a></strong></td><td class="style4">'.$region.'</td></tr>';


}$nombre_ville=count($nombre_ville)-1;


if(!$ville_chk)$message="Aucune ville correspondant à votre recherche n'a été trouvée.";//没有找到城市

}else{$message="Veuillez saisir au moins 3 chiffres!";}


}else{



if(strlen($m)>=3){


$suju_codepo='<tr><td class="style5">Ville</td><td class="style5">Code postal</td><td class="style5">Département</td><td class="style5">Région</td></tr>
<tr><td></td><td></td><td>D</td><td></td></tr>';


//输入城市时*******************************
$ville=strtolower($m);
$ville=str_replace("-"," ",$ville);
$ville=str_replace("_"," ",$ville);
$ville=str_replace("　"," ",$ville);

$ville=preg_replace("#\bste\b#","saint",$ville);
$ville=preg_replace("#\bst\b#","saint",$ville);
$ville=preg_replace("#\bsainte\b#","saint",$ville);



$ville=preg_replace("#\s{2,}#"," ",$ville);
 
$ville=explode(" ",$ville);
$ville_mot='';
for($i=0;$i<=count($ville)-1;$i++){
$mot=$ville[$i];
$ville_mot.=" AND nom like '%$mot%' ";

}
 
$query_sql = "SELECT nom, cp,id_departement FROM ville  WHERE 1 $ville_mot ORDER BY nom,cp ";
$result = mysql_query($query_sql);
if(!$result) exit('fail&nbsp;'.mysql_error());

$nombre_ville[]='';

 while($gb_array = mysql_fetch_array($result)){
 $nombre_ville[]=$gb_array['nom'];

$codepo=$gb_array['cp'];
$ville_nom=$gb_array['nom'];
$code=$gb_array['id_departement'];
if($ville_nom)$ville_chk=TRUE;else $ville_chk=false;

//departement*************************************************
 



$de_sql = "SELECT * FROM departement WHERE code like '$code' ";
$de_result = mysql_query($de_sql);
if(!$de_result) exit('fail&nbsp;'.mysql_error());
$de_array = mysql_fetch_array($de_result);
 $departement=$arr_suzu[$de_array['daima']];

//region**************************************
$code_re=$de_array['id_region'];
$re_sql = "SELECT * FROM region WHERE id_region = '$code_re' ";
$re_result = mysql_query($re_sql);
if(!$re_result) exit('fail&nbsp;'.mysql_error());
$re_array = mysql_fetch_array($re_result);
$region=$arr_suzu[$re_array['daima']];
//************************************
$suju_titre='';
$suju_codepo.='<tr><td><strong style="border-bottom:#CCCCCC 1px solid;"><a href="ville.php?v='.$ville_nom.'&c='.$codepo.'&d='.$code.'"  class="a4"   >'.$ville_nom.'</a></strong></td><td class="style4">'.$codepo.'</td><td><strong style="border-bottom:#CCCCCC 1px solid;"><a href="departement.php?d='.$code.'"  class="a4"   >'.$departement.'</a></strong></td><td class="style4">'.$region.'</td></tr>';


}$nombre_ville=count($nombre_ville)-1;


if(!$ville_chk)$message="Aucune ville correspondant à votre recherche n'a été trouvée.";//没有找到城市

}else {$message="Veuillez saisir au moins 3 lettres!";}


}

 







}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" 
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta http-equiv="content-language"		content="fr"			/>
<meta name="copyright"		content="http://code-postal-fr.net" />
<meta name="classification"	content="code postal,codes postaux,courrier,poste" />

<meta name="content"		content="Code postal villes : cherchez le code postal d'une ville ou l'inverse parmi 36000 villes et trouvez aussi des suggestions de sites internet locaux (entreprises, loisirs, tourisme, etc.) ainsi qu'une carte de chaque ville." />
    
<meta name="description" content="Code postal villes : cherchez le code postal d'une ville ou l'inverse parmi 36000 villes et trouvez aussi des suggestions de sites internet locaux (entreprises, loisirs, tourisme, etc.) ainsi qu'une carte de chaque ville." />	 
	<meta name="expires"		content="never" />
      
<meta name="keywords" content="codespostaux, codes, postaux, code, postal, recherche, ville, france, rechercher, info, fr, departement, departements, gratuit, service, rechercher, codepostal, code-postal, codes-postaux, code postal, codes postaux, ville francaise" />
<title>Code postal 
<?php 
if($codepo)echo '-',$codepo," ";
if($departement)echo $departement," ";
if($region)echo $region," ";
?> Tous les codes postaux de France</title>
 
<link href="css.css" rel="stylesheet" type="text/css" />
</head>

<body>
<?php require("head.php");?>



<div style="padding:15px;" class="style2">

 <strong style=" font-family: 'Trebuchet MS', Arial, Helvetica, sans-serif; font-size:36px">Code postal des villes françaises</strong><br />
 <br />

<div style="font-size:12px">
<fieldset style=" padding:20px;border:1px solid #f00;" >
<legend>Cherchez le code postal d'une ville ou la ville pour un code postal</legend>
<br />
<br />

<form  id="form1" name="form1" method="post" action=""  >
    <strong>Votre recherche :</strong> <input name="m"  class="STYLE2"    type="text"  value="<?php if($_POST['m']) echo $_POST['m']?>"  size="40"/> <input name="submit1" value="Chercher"  type="submit"    class="tijiaoanniuziti"/>  
      
    
    </form> 
 
<div><?php
 if($message){
 ?><br />

   <div  style=" border:#c62323 1px solid; background-color: #FFBFBF; padding:5px; ">
<strong style="color:#c62323"><?=$message?></strong></div>
<?php
}else{ 
if($_POST['submit1']&&$_POST['m']){
echo '
<br />

<div style="padding:20px; background-color:#FF6868; color:#FFF">
  <div style="border:#fff 1px solid; padding:5px;background-color:#9F0000;">
<table cellspacing="5" cellspacing="5" style="color:#FFF" ><tbody>';
 echo $suju_titre.$suju_codepo;
 if($nombre_ville>1)$nombre_ville=$nombre_ville.' villes';else $nombre_ville=$nombre_ville.' ville';

echo "</tbody></table>
<br />
<div>  <strong>$nombre_ville correspondent à votre recherche.</strong></div>
</div></div>";}
}?>
</div></fieldset>
<br />
  
 
  
 
</div>
</div>
 

</div>
  <br />
<br />
<?php require("foot.php");?>
</body>
</html>