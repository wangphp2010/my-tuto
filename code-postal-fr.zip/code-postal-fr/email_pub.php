<?php 
$email_pub='
<br/><br/><br/><div style="font-family:"Times New Roman", Times, serif;">
  <div style="border:solid 2px #CCCCCC;">
  <div style="padding: 10px; color: #F00; font-weight: bold;">
  
<a href="http://code-postal-fr.net">code-postal-fr.net</a><br />
<br />


Code-Postal-fr.net : Recherchez gratuitement des codes postaux ou des départements parmis les plus de 36 000 communes répertoriées dans notre base de données !
<br />
<br />'."
---l'équipe code-postal-fr.net---</div></div></div>";
?>


