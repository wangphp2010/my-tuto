<?php
header("content-type:text/html;charset=utf-8");

 
$d=$_GET['d'];

if(!$d)exit('fbf');

require("commun/codeconn.php");
require("commun/codeca.php");
  //防止数据恶意注入
function check_input($value)
{
// 去除斜杠
if (get_magic_quotes_gpc())
  {
  $value = stripslashes($value);
  }
  
  $value = mysql_real_escape_string($value);
  
 
return $value;
}

$cod_sql = "SELECT * FROM db508556084.departement WHERE code like '85' ";
$cod_result = mysql_query($cod_sql);
if(!$cod_result) exit('fail&nbsp;'.mysql_error());

$cod_array = mysql_fetch_array($cod_result);
	
$coded=$arr_suzu[$cod_array['daima']];
$code=$cod_array['code'];
$villes="_($coded)";

//echo $villes.'<br />';
//$villes="_(Charente-Maritime)";
 
 
 
  
  
  
  
  
  
 
$daihao="

(

'24236',
'24302',
'24356',
'24428',
'34487',
'41332'
 
 
 
 
 
 
 
 
 )


 

";$de_sql = "SELECT * FROM db508556084.ville WHERE id_ville IN $daihao  ORDER BY id_ville  ";

 
              // $de_sql = "SELECT * FROM db508556084.ville WHERE id_departement LIKE '$code' ORDER BY id_ville  ";
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
$de_result = mysql_query($de_sql);
if(!$de_result) exit('fail&nbsp;'.mysql_error());
while($de_array = mysql_fetch_array($de_result)){
 
$ville=$de_array['nom'];
$ville=str_replace(" ","_",$ville);

$id=$de_array['id_ville'];
$arrondissement=$de_array['arrondissement'];
$canton=$de_array['canton'];

$codecommune=$de_array['codecommune'];
$population=$de_array['population'];
$superficie=$de_array['superficie'];
$cp=$de_array['cp'];

  	 	
 

$url = "http://fr.wikipedia.org/wiki/".$ville; 
$ch = curl_init(); 
$timeout = 5; 
curl_setopt($ch, CURLOPT_URL, $url); 
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1); 
curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, $timeout); 
//在需要用户检测的网页里需要增加下面两行 
//curl_setopt($ch, CURLOPT_HTTPAUTH, CURLAUTH_ANY); 
//curl_setopt($ch, CURLOPT_USERPWD, US_NAME.":".US_PWD); 
$contents = curl_exec($ch); 
curl_close($ch); 
$a=$contents;

$trianle1="#\<[^>]+\>#";
$trianle2="#\<\/\w+\>#";
$a=preg_replace($trianle1,'',$a);
$a=preg_replace($trianle2,'',$a);



 



 //*****************************************
preg_match("#Canton\s.+#", $a, $m);
foreach($m as $val){
	if(preg_match('#\"#', $val))
{  
$val=trim(preg_replace('#\".+#','',trim($val)));
$val=trim(preg_replace("#^Canton de#",'',trim($val)));
}else{ 
$val=trim(preg_replace("#^Canton#",'',trim($val)));
}
	//if($val)echo $val,'<br /><br />';
	
	
	
	}
preg_match("#Coordonnées\s.+#", $a, $mm);
foreach($mm as $vvv){
	
 	//echo $vvv,'<br /><br /><br />';
	
	
	}
	
	
	if(!$m||!$mm){

$url = "http://fr.wikipedia.org/wiki/$ville".$villes; 
$ch = curl_init(); 
$timeout = 5; 
curl_setopt($ch, CURLOPT_URL, $url); 
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1); 
curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, $timeout); 
//在需要用户检测的网页里需要增加下面两行 
//curl_setopt($ch, CURLOPT_HTTPAUTH, CURLAUTH_ANY); 
//curl_setopt($ch, CURLOPT_USERPWD, US_NAME.":".US_PWD); 
$contents = curl_exec($ch); 
curl_close($ch); 
$a=$contents;



  


$trianle1="#\<[^>]+\>#";

$trianle2="#\<\/\w+\>#";


//<td colspan="3" align="center">


$a=preg_replace($trianle1,'',$a);
$a=preg_replace($trianle2,'',$a);


//echo $a;
}

 
 
 //echo $url.'<br /><br />';
 
 
 
 
 
 
 
 
 
 
 
 
 //***************************************************




preg_match("#Arrondissement\s.+#", $a, $m);
foreach($m as $val){
 
  if(preg_match('#\"#', $val))
{
$val=trim(preg_replace('#\".+#','',trim($val)));
$val=trim(preg_replace("#^Arrondissement de#",'',trim($val)));
}else{ 
$val=trim(preg_replace("#^Arrondissement#",'',trim($val)));
}
	
		//if($val){

	if($val&&!$arrondissement){
				$val=check_input($val);

$update_sql = "UPDATE db508556084.ville SET arrondissement ='$val' WHERE id_ville = '$id' LIMIT 1";
if(!mysql_query($update_sql))   echo mysql_error(),' ',$id,"<br /><br />";
	
	}
	
	}
		if(!$m){
   			echo '<font color="red" size="70">*******************问题   ',$id,'******************************</font><br />';
   			}


  

preg_match("#Canton\s.+#", $a, $m);
foreach($m as $val){

  if(preg_match('#\"#', $val))
{  
$val=trim(preg_replace('#\".+#','',trim($val)));
$val=trim(preg_replace("#^Canton de#",'',trim($val)));
}else{ 
$val=trim(preg_replace("#^Canton#",'',trim($val)));
}
				$val=check_input($val);

	if($val&&!$canton){
		
		
$update_sql = "UPDATE db508556084.ville SET canton ='$val' WHERE id_ville = '$id' LIMIT 1";
if(!mysql_query($update_sql))  echo mysql_error(),' ',$id,"<br /><br />";
	
	}
	}



preg_match("#Code postal\s.+#", $a, $m);
foreach($m as $val){
	$val=trim(str_replace("Code postal",'',$val));
	if($val){
		
$update_sql = "UPDATE db508556084.ville SET cp2 ='$val' WHERE id_ville = '$id' LIMIT 1";
if(!mysql_query($update_sql)) echo mysql_error(),' ',$id,"<br /><br />";
	
	}
	
	}


//********
preg_match("#Code commune\s.+#", $a, $m);
foreach($m as $val){$val=trim(str_replace("Code commune",'',$val));
	if($val&&!$codecommune){
		
$update_sql = "UPDATE db508556084.ville SET codecommune ='$val' WHERE id_ville = '$id' LIMIT 1";
if(!mysql_query($update_sql))  echo mysql_error(),' ',$id,"<br /><br />";
	
	}}


preg_match("#Population\smunicipale\s.+#", $a, $m);
foreach($m as $val){
	$val=trim(str_replace("Population",'',$val));
	$val=trim(str_replace("municipale",'',$val));
	$val=trim(str_replace("&#160;",'',$val));
	$val=trim(str_replace("hab. (2011)",'',$val));
 	if($val&&!$population){
		
$update_sql = "UPDATE db508556084.ville SET population ='$val' WHERE id_ville = '$id' LIMIT 1";
if(!mysql_query($update_sql))  echo "<br /><br /><br /><br />",mysql_error(),' ',$id,"<br /><br /><br /><br />";
	
	}}

 
 preg_match("#Coordonnées\s.+#", $a, $m);foreach($m as $val){
 	
	
	preg_match("#\/[^/]+\/#", $val, $ms);
foreach($ms as $vals){
	$vals=trim(str_replace("/",'',$vals));
	
$val=trim(str_replace("Coordonnées",'',$val));
$val=trim(str_replace("&#160;",'',$val));

$lon =trim(str_replace(";","",strrchr($val, ";")));
 
 
$val=strrchr($val, "/"); 
$val=str_replace($lon,"",$val);
$val=str_replace("/","",$val);
$lat=trim(str_replace(";","",$val));

	if($val){
		
$update_sql = "UPDATE db508556084.ville SET lat ='$lat',lon = '$lon' WHERE id_ville = '$id' LIMIT 1";
if(!mysql_query($update_sql))   echo mysql_error(),' ',$id,"<br /><br />";
	
	}}
}
 




preg_match("#Superficie\s.+#", $a, $m);foreach($m as $val){
	$val=trim(str_replace("Superficie",'',$val));	
	$val=trim(str_replace("&#160;",'',$val));
	$val=trim(str_replace("km2",'',$val));

	if($val&&!$superficie){
		
$update_sql = "UPDATE db508556084.ville SET superficie ='$val' WHERE id_ville = '$id' LIMIT 1";
if(!mysql_query($update_sql))  echo mysql_error(),' ',$id,"<br /><br />";
	
	}}


 echo "$ville $id $cp 结束<br />";
 echo '************************************************************************************************************************************************<br /><br /><br /><br />';
}//while


  
echo "<br /><br /><br /><br /><br />全部结束"
?>