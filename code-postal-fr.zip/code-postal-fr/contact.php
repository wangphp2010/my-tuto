<?php
 



// 禁止非 POST 方式访问
if(isset($_POST['submit'])){
 
// 表单信息处理
    $titre = $_POST['titre'];
	$tel = $_POST['tel'];
	$nom = ucwords(strtolower(htmlspecialchars(trim($_POST['nom']))));
	$email = htmlspecialchars(trim($_POST['email']));
	$neirong1 = stripslashes(htmlspecialchars(trim($_POST['content'])));
   $neirong = stripslashes(htmlspecialchars(trim($_POST['content'])));

if(!$tel)exit('Veuillez mettre votre tel!');
if(!$nom)exit('Veuillez mettre votre nom!');
$myreg = "/^\w+([-+.']\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*$/";
if(!preg_match($myreg,$email))exit('Format mail incorrect!');

if(!$email)exit('Veuillez mettre votre mail!');
if(!$neirong)exit('Veuillez mettre votre message!');
if(!$titre)exit('Vous êtes Madame ou Monsieur!');



 
  $too = "yanick2019@yahoo.fr"; 
	     
	    $datee = date("Y年m月d日");
	     
	    $headerss  = 'MIME-Version: 1.0' . "\r\n";
	    $headerss .= 'Content-type: text/html; charset=utf-8' . "\r\n";
	    $headerss .= "To: $too \r\n";
	    $headerss .= "From: $email" . "\r\n";
	 
	    $subjectt = "有人在code-postal-fr.net上留言"; 
	    $subjectt = "=?UTF-8?B?".base64_encode($subjectt)."?=";
	  
	    $contentt = '<br />'; 

	
    $contentt .= "留言者姓名&nbsp;:"."$titre&nbsp;"."$nom"."<br />"; 
	
	
	
	
	$contentt .= "电话&nbsp;:".$tel."<br />"; 
	$contentt .= "email:&nbsp;".$email."<br />"; 
	$contentt .= "留言内容 : &nbsp;".nl2br(stripslashes($neirong1))."<br />"; 
 
	$contentt .= "$datee".'<br />'; 
	 
  if(mail($too, $subjectt, $contentt, $headerss))//给自己发邮件结束
exit('<script language="javascript">alert("Votre message a été enregistré");self.location = "/contact.php";</script>');
  
 }
?>
 <!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" 
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta http-equiv="content-language"		content="fr"			/>
<meta name="copyright"		content="http://code-postal-fr.net" />
<meta name="classification"	content="code postal,codes postaux,courrier,poste" />

<meta name="content"		content="Code postal villes : cherchez le code postal d'une ville ou l'inverse parmi 36000 villes et trouvez aussi des suggestions de sites internet locaux (entreprises, loisirs, tourisme, etc.) ainsi qu'une carte de chaque ville." />
    
<meta name="description" content="Code postal villes : cherchez le code postal d'une ville ou l'inverse parmi 36000 villes et trouvez aussi des suggestions de sites internet locaux (entreprises, loisirs, tourisme, etc.) ainsi qu'une carte de chaque ville." />	 
	<meta name="expires"		content="never" />
      
<meta name="keywords" content="codespostaux, codes, postaux, code, postal, recherche, ville, france, rechercher, info, fr, departement, departements, gratuit, service, rechercher, codepostal, code-postal, codes-postaux, code postal, codes postaux, ville francaise" />
<title>Code postal . Tous les codes postaux de France</title>
 
<link href="css.css" rel="stylesheet" type="text/css" />
<style type="text/css">
 @import url("webfonts/Sansation_Regular/stylesheet.css");

</style>
</head>

<body>
<?php require("head.php");?>


<table width="978" border="0" cellpadding="0" cellspacing="0" style="font-family:'Times New Roman', Times, serif" >
   <tr>
    <td width="219" height="252">&nbsp;</td>
    <td width="508" ><form  method="post" action=""  >		
              <table width="100%" border="0" cellpadding="0" cellspacing="4" bgcolor="#DAE9FE">
                 <tr>
                  <td height="37" colspan="2"  align="center" bgcolor="#FFFFFF"><span class="STYLE75"><span class="titre">Votre message </span></span></td>
                </tr>
				  <tr>
                  <td width="232" height="22"  align="left" bgcolor="#FFFFFF" class="STYLE72">&nbsp;Vous êtes:</td>
                  <td width="264" bgcolor="#FFFFFF">
                      
                  &nbsp;Madame
                  <input   name="titre"  type="radio"  value="Madame" checked="checked"  />
                  &nbsp;Monsieur
                  <input  type="radio"   name="titre"  value="Monsieur"  />             </td>
                </tr
				   ><tr>
                  <td height="22"  align="left" bgcolor="#FFFFFF" class="STYLE72">&nbsp;Votre tél:</td>
                  <td bgcolor="#FFFFFF">
                      
                  <input type="text"  id="tel" name="tel"  onKeyUp="value=value.replace(/[^\d\.]/g,'')" style= "width:263px;" required="required" />                </td>
                </tr>
                <tr>
                  <td height="22"  align="left" bgcolor="#FFFFFF" class="STYLE72">&nbsp;Votre nom:</td>
                  <td bgcolor="#FFFFFF">
                      
                  <input type="text"  id="nom" name="nom"  style= "width:263px;" required="required"  />                </td>
                </tr>
                <tr>
                  <td height="22" align="left" bgcolor="#FFFFFF"   class="STYLE72">&nbsp;Votre email:</td>
                  <td bgcolor="#FFFFFF">
                      
                  <input type="email"  id="email" name="email" style= "width:263px;" required="required"/>                </td>
                </tr>
               
             
             
                <tr>
                  <td height="23" align="left" bgcolor="#FFFFFF"  class="STYLE72">&nbsp;Message:</td>
                  <td rowspan="3" >
                    <textarea name="content" id="content" style= " width:263px;height:300px " required="required"></textarea>            </td>
                </tr>
                <tr>
                  <td height="245" bgcolor="#FFFFFF"><!--DWLayoutEmptyCell-->&nbsp;</td>
                </tr>
                <tr>
                  <td height="24"  align="right" bgcolor="#FFFFFF"><input type="submit" name="submit"   value="envoyer" /></td>
                </tr>
                
                
    
        </table>
            </form></td>
    <td width="251">&nbsp;</td>
  </tr>
</table>
 
 <br />
<br />
<?php require("foot.php");?>
</body>
</html>