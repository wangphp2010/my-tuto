<?php
 $conno6 = @mysql_connect("db616723578.db.1and1.com","dbo616723578","onfigdashboardjsessionid");
$db_selected = mysql_select_db("db616723578",$conno6);

mysql_query("set names 'UTF8'");



?>