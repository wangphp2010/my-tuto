<?php
session_start();
header("content-type:text/html;charset=utf-8");
require('commun/codeconn.php');

 set_time_limit(0);

   
$count=0;
//128801455

  function strK($a)
 {
	 $a=trim($a);
 
	 return str_replace(" ","+++",$a);
	 }
 

  if(!$_GET['get'])exit;
 
$num= $_GET['num']?$_GET['num']:0;
                        
for($i=$_GET['get'];$i<=129117566;$i++)
//for($i=$_GET['get'];$i<=129117566;$i++)
	 {
		 
		 if($count>=50){
	  $count=0;
 exit("<script>self.location = 'ade.php?get=$i&num=$num';</script>");
 	  }
	  
	  
		 $count++;
 echo $count." -  "; 


$url="http://achat-vente-terrain.vivastreet.com/annonces-terrain+etranger-br/terrain-250-m2---caponga--br-sil-/".$i; 
		 
	

 


 

$url=str_replace(" ","+",$url);


 


/*
	 
$ch = curl_init(); 
$timeout = 5; 
curl_setopt($ch, CURLOPT_URL, $url); 
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1); 
curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, $timeout); 
//在需要用户检测的网页里需要增加下面两行 
//curl_setopt($ch, CURLOPT_HTTPAUTH, CURLAUTH_ANY); 
//curl_setopt($ch, CURLOPT_USERPWD, US_NAME.":".US_PWD); 
$contents = curl_exec($ch); 
curl_close($ch); 

*/
 /*
$handle = fopen($url, "rb"); 
$contents = stream_get_contents($handle); 
fclose($handle);
 */
 
$contents =file_get_contents($url);
 	
	
 $a=$contents;
 
preg_match('#data-phone-number=\"[^\"]+\"#', $a, $m);
foreach($m as $val){
  $val=str_replace('"','',$val);
  $val=str_replace('data-phone-number','',$val);
  $val=str_replace('=33','0',$val);
  $val=str_replace('=','',$val);
  $val=str_replace(' ','',$val);
  $val=preg_replace("#\D#",'',$val);
 
	$tel=trim($val);
	
	
	} 
	
	
preg_match("#\b[a-zA-Z0-9_-]+(\.[a-zA-Z0-9_-]+)*@[a-zA-Z0-9_-]+\.(com|fr|cn|it|be|net|cc|ca|org|lu|es|eu|de|ru)\b#", $contents, $emailArr);
$email=$emailArr[0];
 if($emailArr[0]){if(mysql_query("INSERT INTO email(email)VALUE('$email')"))echo "插入email $email ";}
 
 
 
 

 
 
  if(!$tel||preg_match("#^08#",$tel)||!preg_match("#^0#",$tel))
{
	  
	   echo '电话不匹配'.$i.'---------<br />';
	  continue;
 }
 
  preg_match("#le\s\d\d\/\d\d\/20\d\d#", $contents, $m);
 
$createtime=strtotime(str_replace("/","-",str_replace("le","",$m[0])).date("H:i:s")); 

 


preg_match('#<h1 class="kiwii-font-xlarge kiwii-margin-none">[^<]+#', $a, $m);

foreach($m as $val){
   $val=str_replace('<h1 class="kiwii-font-xlarge kiwii-margin-none">','',$val);
 
	$titre=trim($val);
	
	}   
 
$trianle1="#\<[^>]+\>#";
$trianle2="#\<\/\w+\>#";
$trianle3="#<script[^>].*?>.*?</script>#si";
$trianle4="#<script>.*?</script>#si";
$trianle5="#<style>.*?</style>#si";



$a=preg_replace($trianle5,'',$a);
$a=preg_replace($trianle4,'',$a);
$a=preg_replace($trianle3,'',$a);
$a=preg_replace($trianle1,'',$a);
$a=preg_replace($trianle2,'',$a);


 
$aa=$a;
$aa=preg_replace('/\s(?=\s)/','', $aa);
$aa=preg_replace('/\s/','', $aa);

 
 
 
 
  //$a=preg_replace('/\n/','@', $a);
 
//echo $a.'<br /><br />******************************<br /><br />';
  



	
	
preg_match("#Loyer\d+#", $aa, $m);

foreach($m as $val){
 $val=preg_replace('/\D/','', $val);
  $loyer=$val;	
	} 

preg_match("#Prix/Loyer\d+#", $aa, $m);

foreach($m as $val){
 $val=preg_replace('/\D/','', $val);
 $prix=$val;   
	} 

 preg_match("#Prix\d+#", $aa, $m);

foreach($m as $val){
 $val=preg_replace('/\D/','', $val);

 $prix=$val;    
	}
	if(!$prix){ preg_match("#\d+&nbsp;&euro;#", $aa, $m);

foreach($m as $val){
 $val=preg_replace('/\D/','', $val);

 $prix=$val;  
	}}
	
	
  
	


preg_match("#<div\sclass=\"shortdescription\">[\d\D]+?</div>#", $contents, $m);
 foreach($m as $val){
	 $val=str_replace('<div class="shortdescription">',"",$val);
	 $val=str_replace('</div>',"",$val);
	 $val=str_replace('<br>',"\r\n",$val);
	 $val=str_replace('<p>',"\r\n",$val);
	 $val=str_replace('</p>',"\r\n",$val);
	 $val=str_replace('<br />',"\r\n",$val);

	 $description=$val;
 }


	  
	  
  

	
	
preg_match("#Surface\d+#", $aa, $m);
foreach($m as $val){
 $val=preg_replace('/\D/','', $val);

$val=str_replace("Surface",'', $val);
$surface=$val;	
} 
	
	


preg_match("#Nbredepièces\d+#", $aa, $m);
foreach($m as $val){
	 $val=preg_replace('/\D/','', $val);

$val=str_replace("Nbredepièces",'', $val);
$piece=$val;	
} 	
	
	
preg_match("#Ville/Codepostal.*?\-\d{5}#", $aa, $m);
foreach($m as $val){
  $val= strrchr($val,'-');
  $val=str_replace("-",'', $val);
 $val=preg_replace('/\D/','', $val);

 $codepo=trim($val);	
}

 if(!$codepo)
{
 preg_match("#<div class=\"kiwii-no-link-color kiwii-no-link-decoration\">[\d\D]+?</div>#", $contents, $m);
if($m[0]){

$codepo=$m[0];
$codepo=preg_replace("#<div class=\"kiwii-no-link-color kiwii-no-link-decoration\">#","",$codepo);
$codepo=str_replace("</div>","<br/>",$codepo);

 
preg_match_all("#\w+?<br/>#",$codepo,$m);
$codepo=str_replace("<br/>","",$m[0][1]);
$ville=str_replace("<br/>","",$m[0][2]);
 
 
}

  }
 
preg_match("#\+[^\+]*\-".$codepo."#", $contents, $m);
foreach($m as $val){
   	 
  preg_match("#\+.*?\d#", $val, $valm);
  $ville=str_replace("+","",$valm[0]);
  $ville=str_replace("-"," ",$ville);
  $ville=preg_replace("#\d#","",$ville);
  $ville=ucfirst($ville);
  $ville=trim($ville);
 	
   }


 
 
   
 



 
 

preg_match("#Année\d{4}#", $aa, $m);
foreach($m as $val){
	 $val=preg_replace('/\D/','', $val);

  $val=str_replace("Année",'', $val);
  $annee=$val;	

  
}	
 
preg_match("#Energie</td> <td class=\"kiwii-padding-top-xxxsmall\">[\d\D]+?</td>#", $contents, $m);
$carburant=$m[0];
$carburant=trim(preg_replace("#Energie</td> <td class=\"kiwii-padding-top-xxxsmall\">([\d\D]+?)</td>#",'$1', $carburant));
  
if($carburant=='Diesel')$carburant=52;
elseif($carburant=='Essence')$carburant=51;
elseif($carburant=='Electrique')$carburant=53;
elseif($carburant=='GPL')$carburant=54;
 else $carburant='';



preg_match("#Marque/Modèle</td> <td class=\"kiwii-padding-top-xxxsmall\">[\d\D]+?</td>#", $contents, $m);
$marque=$m[0];
$marque=trim(preg_replace("#Marque/Modèle</td> <td class=\"kiwii-padding-top-xxxsmall\">([\d\D]+?)</td>#",'$1', $marque));


$marque=strK($marque);




preg_match("#Kilométrage\d+km#", $aa, $m);
foreach($m as $val){
	 $val=preg_replace('/\D/','', $val);

  $val=str_replace("km",'', $val);
  $val=str_replace("Kilométrage",'', $val);
  $km=$val;	
}


 
	preg_match("#Typed'annonceAgenceOffre#", $aa, $m);
	foreach($m as $val){
	$val=str_replace("Typed'annonce",'',$val);
	$val=str_replace("Offre",'',$val);
	$papro=$val;
	
	}

  
preg_match("#Typed'annonceProfessionnelOffre#", $aa, $m);
	foreach($m as $val){
	$val=str_replace("Typed'annonce",'',$val);
	$val=str_replace("Offre",'',$val);	
	$papro=$val;

	}
	if($papro=='Agence'||$papro=='Professionnel')$papro=222;else $papro=221;
	
	
if(preg_match("#title\=\"VEHICULES\s\-\sEQUIPEMENTS\"#", $contents))
   $categorie=280;
 
if(preg_match("#title\=\"Voitures\s\-\sutilitaires\"#", $contents))
    $categorie=1;
if(preg_match("#title\=\"Motos\s\-\sscooters\"#", $contents))
    $categorie=2;
	
	
	
	
	
	
if(preg_match("#title\=\"Vente\simmobilière\"#", $contents)){
		
		$categorie=5;
		$location=86;
		
    if(preg_match("#title\=\"Appartement\sa\svendre\"#", $contents))
    {$typeimo=76;$loyer='';}

    if(preg_match("#title\=\"Maisons\"#", $contents))
    {$typeimo=77;$loyer='';}
	
    if(preg_match("#title\=\"Parkings\s\-\sGarages\"#", $contents))
    {$typeimo=78;$loyer='';}
	 if(preg_match("#title\=\"Terrains\"#", $contents))
    {$typeimo=79;$loyer='';}
 }
	
	if(preg_match("#title\=\"Vente immobiliere\"#i", $contents)){
		
		$categorie=5;
		$location=86;
		
    if(preg_match("#title\=\"Appartement#", $contents))
    {$typeimo=76;$loyer='';}

    if(preg_match("#title\=\"Maisons#", $contents))
    {$typeimo=77;$loyer='';}
	
    if(preg_match("#title\=\"Parkings#", $contents))
    {$typeimo=78;$loyer='';}
	 if(preg_match("#title\=\"Terrains#", $contents))
    {$typeimo=79;$loyer='';}
 }
 
 
 
	
	
if(preg_match("#title\=\"Location\simmobilière\"#i", $contents))
{$categorie=5;$location=87;
	
  if(preg_match("#title\=\"Appartements\svides\"#", $contents)||preg_match("#title\=\"Appartements\smeublés\"#", $contents))
    {$typeimo=76;if(!$loyer)$loyer=$prix;$prix='';}

  if(preg_match("#title\=\"Maisons\svides\"#", $contents)||preg_match("#title\=\"Maisons\smeublés\"#", $contents))
    {$typeimo=77;if(!$loyer)$loyer=$prix;$prix='';}

  if(preg_match("#title\=\"Parkings\s\-\sGarages\"#", $contents)&&preg_match("#title\=\"Location\simmobilière\"#", $contents))
    {$typeimo=78;if(!$loyer)$loyer=$prix;$prix='';}
}

	
if(preg_match("#title\=\"Location Immobiliere\"#i", $contents))
{$categorie=5;$location=87;
	
  if(preg_match("#title\=\"Appartement#", $contents)||preg_match("#title\=\"Appartements#", $contents))
    {$typeimo=76;if(!$loyer)$loyer=$prix;$prix='';}

  if(preg_match("#title\=\"Maison#", $contents)||preg_match("#title\=\"Maisons\smeublés\"#", $contents))
    {$typeimo=77;if(!$loyer)$loyer=$prix;$prix='';}

  if(preg_match("#title\=\"Parkings#", $contents)&&preg_match("#title\=\"Location\simmobiliere\"#", $contents))
    {$typeimo=78;if(!$loyer)$loyer=$prix;$prix='';}
}















if(preg_match("#title=\"Locations vacances\"#i", $contents)||preg_match("#title=\"Location vacances\"#i", $contents))
 {$categorie=5;$location=87;$typeimo=80;if(!$loyer)$loyer=$prix;$prix='';}


if(preg_match("#title\=\"Colocations\"#", $contents)&&preg_match("#title\=\"IMMOBILIER\"#", $contents))
 {$categorie=5;$location=87;$typeimo=76;if(!$loyer)$loyer=$prix;$prix='';}
 









 if(preg_match("#title\=\"Bureaux\s\-\sCommerces\"#", $contents)&&preg_match("#title\=\"Bureaux\"#", $contents))
    {$categorie=7; $typebureau=73; if($prix&&$prix<5000){$loyer=$prix;$prix='';}}



 if(preg_match("#title\=\"Bureaux\s\-\sCommerces\"#", $contents))
    {
		
if(preg_match("#title\=\"Boutiques\s\-\sCommerces\"#", $contents)||preg_match("#title\=\"Fonds de Commerce\"#", $contents)||preg_match("#title\=\"Fond de Commerce\"#", $contents))
		$categorie=6; 
		
		 if(preg_match("#restaurant#i", $description)||preg_match("#bar#i", $description)||preg_match("#snack#i", $description)||preg_match("#RESTAURATION#i", $description)||preg_match("#hotel#i", $description)||preg_match("#pizza#i", $description)||preg_match("#Sandwicherie#i", $description)||preg_match("#pizzeria#i", $description)||preg_match("#livraison#i", $description)||preg_match("#Creperie#i", $description)||preg_match("#saladerie#i", $description)||preg_match("#Kebab#i", $description)) 
		 $activite=41;
		 if(preg_match("#boucherie#i", $description)||preg_match("#supermarche#i", $description)||preg_match("#Terminal\sde\scuisson#i", $description)||preg_match("#fruit#i", $description)||preg_match("#légumes#i", $description)||preg_match("#charcuterie#i", $description)||preg_match("#patisserie#i", $description)||preg_match("#Boulangerie#i", $description)||preg_match("#Alimen#i", $description)||preg_match("#Traiteur#i", $description)||preg_match("#epicerie#i", $description)) 
		 $activite=42;
		 if(preg_match("#souvenir#i", $description)||preg_match("#fleur#i", $description)||preg_match("#bazar#i", $description))
         $activite=43;

		 if(preg_match("#Librairie#i", $description)||preg_match("#Papeterie#i", $description)||preg_match("#Presse#i", $description)||preg_match("#Tabac#i", $description)||preg_match("#pmu#i", $description)||preg_match("#fdj#i", $description))  
		 $activite=45;
		 if(preg_match("#institut\sde\sbeauté#i", $description)||preg_match("#coiffure#i", $description)||preg_match("#beauté#i", $description))
		 $activite=46;
		 
	
	
 
		
	  		 if(preg_match("#restaurant#i", $titre)||preg_match("#bar#i", $titre)||preg_match("#snack#i", $titre)||preg_match("#RESTAURATION#i", $titre)||preg_match("#hotel#i", $titre)||preg_match("#pizza#i", $titre)||preg_match("#Sandwicherie#i", $titre)||preg_match("#pizzeria#i", $titre)||preg_match("#livraison#i", $titre)||preg_match("#Creperie#i", $titre)||preg_match("#saladerie#i", $titre)||preg_match("#Kebab#i", $titre)) 
		 $activite=41;
		 if(preg_match("#boucherie#i", $titre)||preg_match("#supermarche#i", $titre)||preg_match("#Terminal\sde\scuisson#i", $titre)||preg_match("#fruit#i", $titre)||preg_match("#légumes#i", $titre)||preg_match("#charcuterie#i", $titre)||preg_match("#patisserie#i", $titre)||preg_match("#Boulangerie#i", $titre)||preg_match("#Alimen#i", $titre)||preg_match("#Traiteur#i", $titre)||preg_match("#epicerie#i", $titre)) 
		 $activite=42;
		 if(preg_match("#souvenir#i", $titre)||preg_match("#fleur#i", $titre)||preg_match("#bazar#i", $titre))
         $activite=43;

		 if(preg_match("#Librairie#i", $titre)||preg_match("#Papeterie#i", $titre)||preg_match("#Presse#i", $titre)||preg_match("#Tabac#i", $titre)||preg_match("#pmu#i", $titre)||preg_match("#fdj#i", $titre))  
		 $activite=45;
		 if(preg_match("#institut\sde\sbeauté#i", $titre)||preg_match("#coiffure#i", $titre)||preg_match("#beauté#i", $titre))
		 $activite=46; 
	  
		 
		 
	
	
		  
	}

 
 if(preg_match("#title\=\"ANIMAUX\"#", $contents))
    {$categorie=34; }//annimal


 if(preg_match("#title\=\"SERVICES\s\-\sAIDE\sA\sLA\sPERSONNE\"#", $contents))
    {$categorie=210; }


 if(preg_match("#title\=\"SERVICES\s\-\sAIDE\sA\sLA\sPERSONNE\"#", $contents))
    {//service
		$categorie=10; 
		
		if(preg_match("#title\=\"Artisans\s\-\sDépannages\"#", $contents))
		$typeservice=260;
		if(preg_match("#title\=\"Associations\s\-\sBénévolat\"#", $contents))
		$typeservice=259;
		if(preg_match("#title\=\"Castings,\smodèles,\sphotographes\"#", $contents))
		$typeservice=258;
		if(preg_match("#title\=\"Covoiturages\"#", $contents))
		$typeservice=257;		
		if(preg_match("#title\=\"Déménageurs\"#", $contents))
		$typeservice=256;
		if(preg_match("#title\=\"Horoscope\s\-\sVoyance\"#", $contents))
		$typeservice=255;  
		if(preg_match("#title\=\"Informatique\"#", $contents))
		$typeservice=254; 
		if(preg_match("#title\=\"Organisations\sd\'evènements\"#", $contents))
		$typeservice=253; 
		if(preg_match("#title\=\"Santé,\sforme,\sbeauté\"#", $contents))
		$typeservice=252; 
		if(preg_match("#title\=\"Services\sImmobiliers\"#", $contents))
		$typeservice=251; 
		  
		  
		   
		    
	}


 if(preg_match("#title\=\"Ameublement\s\-\sart\sde\sla\stable\"#", $contents))
    {$categorie=18; } 

 if(preg_match("#title\=\"Electroménager\"#", $contents))
    {$categorie=19; }  

if(preg_match("#title\=\"Décoration\s\-\sart\"#", $contents))
    {$categorie=21; } 

if(preg_match("#title\=\"MAISON\s\-\sMODE\"#", $contents)&&preg_match("#title\=\"Bricolage\s\-\sJardinage\"#", $contents))
    {$categorie=23; } 
	

  
	
	
	
if(preg_match("#title\=\"Vêtements\s\-\smode\s\-\saccessoires\"#", $contents))
    {
		if(preg_match("#title\=\"Vêtements\"#", $contents))
          $categorie=25;
		if(preg_match("#title\=\"Chaussures\"#", $contents))
          $categorie=26;
		if(preg_match("#title\=\"Bijoux\"#", $contents)||preg_match("#title\=\"Montres\"#", $contents))
          $categorie=28;
		if(preg_match("#title\=\"Accessoires\s\-\sBagagerie\"#", $contents))
          $categorie=27;
		  if(preg_match("#title\=\"Beauté\s\-\sSanté\"#", $contents))
          $categorie=28;
		
	} 

if(preg_match("#title\=\"Equipements\sbébés\"#", $contents)&&preg_match("#title\=\"ENFANCE\"#", $contents))
          $categorie=29;
		  
if(preg_match("#title\=\"Vêtements\sbébés\"#", $contents)&&preg_match("#title\=\"ENFANCE\"#", $contents))
          $categorie=30;

if(preg_match("#title\=\"Jeux\s\-\sJouets\"#", $contents)&&preg_match("#title\=\"ENFANCE\"#", $contents))
          $categorie=38;




if(preg_match("#title\=\"Equipements\sbébés\"#", $contents)&&preg_match("#title\=\"ENFANCE\"#", $contents))
          $categorie=29;
		  
if(preg_match("#title\=\"Vêtements\sbébés\"#", $contents)&&preg_match("#title\=\"ENFANCE\"#", $contents))
          $categorie=30;

if(preg_match("#title\=\"MULTIMEDIA\"#", $contents))
{
	if(preg_match("#title\=\"Informatique\"#", $contents))
       $categorie=15;
	
	if(preg_match("#title\=\"Jeux\svidéo\s\-\sconsoles\"#", $contents))
       $categorie=16;
	if(preg_match("#title\=\"Image\s\-\sSon\"#", $contents))
       $categorie=17; 
	if(preg_match("#title\=\"Téléphonie\"#", $contents))
       $categorie=208;  
	   	
}
          






if(preg_match("#title\=\"LOISIRS\"#", $contents))
{
	if(preg_match("#title\=\"CDs\"#", $contents))
       $categorie=32;
	if(preg_match("#title\=\"DVD\"#", $contents))
       $categorie=31;
	if(preg_match("#title\=\"Livres\"#", $contents))
       $categorie=33; 
	if(preg_match("#title\=\"Sports\s\-\shobbies\"#", $contents))
       $categorie=35;  
	if(preg_match("#title\=\"Instruments\sde\smusique\"#", $contents))
       $categorie=36;     
	if(preg_match("#title\=\"Collections\"#", $contents))
       $categorie=37;   
	if(preg_match("#title\=\"Vin\s\-\sGastronomie\"#", $contents))
       $categorie=39;   
	if(preg_match("#title\=\"Vins\s\-\sGastronomie\"#", $contents))
       $categorie=39;  	
	if(preg_match("#title\=\"Billetterie\"#", $contents))
       $categorie=11;      
 }

	

if(preg_match("#title\=\"Offres\sd'emploi\"#", $contents)&&preg_match("#http\:\/\/annonces\-emploi\.vivastreet\.com\/annonces\-emploi#", $contents))
{
	$categorie=13;
	
	if(preg_match("#title\=\"Agriculture\s\-\sEnvironnement\"#", $contents))
	$typetra=261;
	
	if(preg_match("#title\=\"Assistanat\s\-\sSecrétariat\s\-\sAccueil\"#", $contents))
	$typetra=262;
	
	if(preg_match("#title\=\"Automobile\"#", $contents))
	$typetra=263;
	
	if(preg_match("#title\=\"BTP\"#", $contents))
	$typetra=264;
	
	if(preg_match("#title\=\"Commerce\set\sprestation\sde\sproximité\"#", $contents))
	$typetra=265;
	
	if(preg_match("#title\=\"Commercial\s\-\sVente\"#", $contents))
	$typetra=266;
	
	if(preg_match("#title\=\"Comptabilité\s\-\sGestion\s\-\sFinance\"#", $contents))
	$typetra=267;
	
	if(preg_match("#title\=\"Direction\s\-\sResponsable\scentre\sde\sprofit\"#", $contents))
	$typetra=268;
	
	if(preg_match("#title\=\"Fonction\spublique\"#", $contents))
	$typetra=269;
	
	if(preg_match("#title\=\"Immobilier\"#", $contents))
	$typetra=270;
	
	if(preg_match("#title\=\"Industrie\s\-\sProduction\"#", $contents))
	$typetra=271;
	
	if(preg_match("#title\=\"Informatique\s\-\sInternet\s\-\sTélécom\"#", $contents))
	$typetra=272;
	
	if(preg_match("#title\=\"Marketing\s\-\sCommunication\"#", $contents))
	$typetra=273;
	
	if(preg_match("#title\=\"Ressources\shumaines\s\-\sFormation\s\-\sEnseignement\"#", $contents))
	$typetra=274;
	
	if(preg_match("#title\=\"Santé\s\-\sSocial\"#", $contents))
	$typetra=275;
	
	if(preg_match("#title\=\"Services\sà\sdomicile\"#", $contents))
	$typetra=276;
	
	if(preg_match("#title\=\"Tourisme\s\-\sHôtellerie\s\-\sRestauration\s\-\sLoisirs\"#", $contents))
	$typetra=277;
	
	if(preg_match("#title\=\"Transport\s\-\sLogistique\"#", $contents))
	$typetra=278;
	
	if(preg_match("#title\=\"Indépendant\sVDI\"#", $contents))
	$typetra=279;


}	 


$offre=219;	
	
	if(preg_match("#title\=\"Recherches\sd\'emploi\"#", $contents)&&preg_match("#http\:\/\/annonces\-emploi\.vivastreet\.com\/annonces\-emploi#", $contents))
{
	$categorie=13;
		$offre=220;
		if(preg_match("#title\=\"Agriculture\s\-\sEnvironnement\"#", $contents))
	$typetra=261;
	
	if(preg_match("#title\=\"Assistanat\s\-\sSecrétariat\s\-\sAccueil\"#", $contents))
	$typetra=262;
	
	if(preg_match("#title\=\"Automobile\"#", $contents))
	$typetra=263;
	
	if(preg_match("#title\=\"BTP\"#", $contents))
	$typetra=264;
	
	if(preg_match("#title\=\"Commerce\set\sprestation\sde\sproximité\"#", $contents))
	$typetra=265;
	
	if(preg_match("#title\=\"Commercial\s\-\sVente\"#", $contents))
	$typetra=266;
	
	if(preg_match("#title\=\"Comptabilité\s\-\sGestion\s\-\sFinance\"#", $contents))
	$typetra=267;
	
	if(preg_match("#title\=\"Direction\s\-\sResponsable\scentre\sde\sprofit\"#", $contents))
	$typetra=268;
	
	if(preg_match("#title\=\"Fonction\spublique\"#", $contents))
	$typetra=269;
	
	if(preg_match("#title\=\"Immobilier\"#", $contents))
	$typetra=270;
	
	if(preg_match("#title\=\"Industrie\s\-\sProduction\"#", $contents))
	$typetra=271;
	
	if(preg_match("#title\=\"Informatique\s\-\sInternet\s\-\sTélécom\"#", $contents))
	$typetra=272;
	
	if(preg_match("#title\=\"Marketing\s\-\sCommunication\"#", $contents))
	$typetra=273;
	
	if(preg_match("#title\=\"Ressources\shumaines\s\-\sFormation\s\-\sEnseignement\"#", $contents))
	$typetra=274;
	
	if(preg_match("#title\=\"Santé\s\-\sSocial\"#", $contents))
	$typetra=275;
	
	if(preg_match("#title\=\"Services\sà\sdomicile\"#", $contents))
	$typetra=276;
	
	if(preg_match("#title\=\"Tourisme\s\-\sHôtellerie\s\-\sRestauration\s\-\sLoisirs\"#", $contents))
	$typetra=277;
	
	if(preg_match("#title\=\"Transport\s\-\sLogistique\"#", $contents))
	$typetra=278;
	
	if(preg_match("#title\=\"Indépendant\sVDI\"#", $contents))
	$typetra=279;
	

	
}
	
	
	
	
	
	
	
	
	
	
	
	
	
		 
		 
		  
	if(preg_match("#title\=\"RENCONTRES\"#", $contents)&&preg_match("#http\:\/\/rencontres\.vivastreet\.com\/annonces\-rencontres#", $contents))
{
	$categorie=14;
 
	preg_match("#Monâge\d\dans#", $aa, $m);
	foreach($m as $val){$age=preg_replace("#\D*#","",$val);}

	
}
		  
	
 
 	if(preg_match("#title\=\"COURS\s\-\sFORMATIONS\"#", $contents))
     $categorie=8; 	
	 if(preg_match("#title\=\"ENGINS\s\-\sMATERIEL\sPRO\"#", $contents))
     $categorie=9;
	 
	 
	 if(preg_match("#title\=\"Vie\sLocale\s\-\sEvenements\"#", $contents))
     $categorie=12;	 
	 
 
	
	
if(preg_match("#title\=\"AUTRES ANNONCES\"#", $contents))
$categorie=40;
	
	
	
	
	
	
	
	
	
	
	
	
	

	
	
	
	
	
	
	
	
	
	
	 
 

 
 
 
 $description=preg_replace("#bon\s*coin#i","",$description);
 $description=preg_replace("#lebon\s*coin#i","",$description);
 $description=preg_replace("#viva\s*street#i","",$description);



$description=str_ireplace("boncoin","",$description);
$description=str_ireplace("bon coin","",$description);
$description=str_ireplace("leboncoin","",$description);
$description=str_ireplace("lebon coin","",$description);
$description=str_ireplace("vivastreet","",$description);
$description=str_ireplace("viva street","",$description);
$description=str_ireplace("toutypass","",$description);

  
 
 
 
$description=urlencode(urlencode(htmlspecialchars_decode(strK($description),ENT_QUOTES)));
$titre=urlencode(urlencode(htmlspecialchars_decode(strK($titre),ENT_QUOTES)));
$ville=urlencode(urlencode(htmlspecialchars_decode(strK($ville),ENT_QUOTES)));


 

if(preg_match("#viva\s*street#i",$titre )||preg_match("#bon\s*coin#i",$titre )||preg_match("#lebon\s*coin#i",$titre ))$titre='';




   
          
  

 if($titre&&$tel&&$codepo&&$categorie&&$description)
 { 

$getUrl="http://monpub.com/ades.php?iidd=$i&titre=$titre&tel=$tel&codepo=$codepo&categorie=$categorie&createtime=$createtime&loyer=$loyer&prix=$prix&surface=$surface&piece=$piece&annee=$annee&carburant=$carburant&km=$km&location=$location&typeimo=$typeimo&typeservice=$typeservice&typebureau=$typebureau&activite=$activite&typetra=$typetra&age=$age&papro=$papro&offre=$offre&marque=$marque&ville=$ville&description=$description"; 
$getUrl=substr($getUrl,0,8083);
/*$ch = curl_init(); 
$timeout = 5; 
curl_setopt($ch, CURLOPT_URL, $url); 
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1); 
curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, $timeout); 
//在需要用户检测的网页里需要增加下面两行 
//curl_setopt($ch, CURLOPT_HTTPAUTH, CURLAUTH_ANY); 
//curl_setopt($ch, CURLOPT_USERPWD, US_NAME.":".US_PWD); 
$result = curl_exec($ch); 
curl_close($ch); */

$result=file_get_contents($getUrl);

//echo $getUrl."<br />";

 /*
   if(mysql_query($insert_sql)){
	   $num++; 
	   echo '插入成功 '.$i.' 已经插入',$num,'<br />';
	   }else echo $i." ".mysql_error().'<br />';
 */
 if( $result=='ok'){
	 
	 $num++;echo '插入成功 '.$i.' 已经插入',$num,'<br />';
	 sleep(1);

	 }
 else echo $getUrl."<br />-".$result,' 失败<br />';
 
 
  } else {
	  $neirong="";
  	 if(!$titre){echo "titre vide ";$neirong.="titre vide $i";}
	  if(!$tel){echo "tel vide ";$neirong.="tel vide $i";}
	  if(!$codepo){echo "codepo vide  "; }
	  if(!$ville){echo "ville vide ";if($codepo)$neirong.="ville vide $i";}
	  if(!$categorie){echo "categorie vide ";$neirong.="categorie vide $i";}
	  if(!$description){echo "description vide ";$neirong.="description vide $i";}
       
		if($neirong!="")mail("yanick2019@yahoo.fr","收集出现问题",$neirong);
		
 
	  echo  "$i<br />";
	  }
 
 

 

 /*
      echo $getUrl.' getUrl<br />';

     echo $codepo.' code<br />';
	 echo $ville.'- ville<br />';
	 	 echo $tel.' tel<br />';
 echo $titre.' -titre<br />';
	 
	 echo $description.' neriong<br /><br />';
	 	 echo $arr_suzu[$categorie].'<br />';

	 
     echo $arr_suzu[$_POST['region']].' region<br />';
     echo $arr_suzu[$_POST['departement']].' departement<br />';
     echo $_POST['arrons'].' arr<br /><br />';
 
	 echo $annee.' annee<br />';
	 echo $km.' km<br />';
	 echo $carburant.' carburant<br />';
	 echo $piece.' piece <br />';
	 echo $surface.' surface<br />';
	
	 echo $prix.' prix<br />';
	 echo $loyer.'  loyer<br /><br />';
	  
	  
	
	 echo $arr_suzu[$location].'<br />';
	 echo $arr_suzu[$typeimo].'<br />';
	 echo $arr_suzu[$typebureau].'<br />';
	 echo $arr_suzu[$activite].'<br />';
	 echo $arr_suzu[$typeservice].'<br />';
	 
	 echo $url.' <br />';
	 echo  '----------------------------------------------------------------------------------------<br /><br />';
  */
	 
	   
$titre="";
$tel="";
$region="";
$codepo="";
$departement="";
$ville="";
$categorie="";
$description="";


$loyer='';
$prix='';
 $surface='';

$piece='';
  $annee='';
$carburant='';
 $km='';
 $contents="";
 $location='';
 $typeimo='';
 $typeservice='';
 $typebureau='';
 $activite='';
 $arrondissement='';
$handle='';
$m='';
$val='';
$typetra='';
 $age='';
 $papro='';
 $offre='';

$createtime='';
$pays='';
  
} //for
 
 
 
   echo "over";
 
 
 
	 
	 
	 
	 
 
?>