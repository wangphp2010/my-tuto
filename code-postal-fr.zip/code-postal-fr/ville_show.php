<?php

 if(!isset($_POST['k']))exit('Erreur directement! Veuillez réessayer ultérieurement!');

require('commun/codeconn.php');
require('commun/codeca.php');

 
 $k=$_POST['k'];
 
 
if(!is_numeric($k)){
	
	 //输入城市时*******************************
	 
$ville=strtolower($k);
$ville=str_replace("-"," ",$ville);
$ville=str_replace("_"," ",$ville);
$ville=str_replace("　"," ",$ville);
$ville=str_replace("oeu","œu",$ville);
 

$ville=preg_replace("#\bste\b#","saint",$ville);
$ville=preg_replace("#\bst\b#","saint",$ville);
$ville=preg_replace("#\bsainte\b#","saint",$ville);
$ville=preg_replace("#\s{2,}#"," ",$ville);


 
$ville=explode(" ",$ville);
$ville_mot='';
for($i=0;$i<=count($ville)-1;$i++){
$mot=$ville[$i];

if(preg_match("#oe#",$mot)){
	$ville_oe1=str_replace("oe","œ",$mot);
    $ville_mot.=" AND (nom like '%$mot%' OR nom like '%$ville_oe1%') ";
	}else {if(preg_match("#œ#",$mot)){
	$ville_oe2=str_replace("œ","oe",$mot);
    $ville_mot.=" AND (nom like '%$mot%' OR nom like '%$ville_oe2%') ";
	}else {$ville_mot.=" AND nom like '%$mot%' ";
}
}


}

	
  $mot_sql = "SELECT nom,cp,id_departement FROM ville WHERE 1 $ville_mot ORDER BY nom,cp LIMIT 15";
 }
 else { if(strlen($k)==5)$s='';else $s=" LIMIT 15 ";

	  $mot_sql = "SELECT nom,cp,id_departement FROM ville WHERE cp like '$k%' ORDER BY nom  $s ";
	  }
	  
	  
	  
	  
	  
	  
	  
$mot_result = mysql_query($mot_sql);
if(!$mot_result) exit('fail&nbsp;'.mysql_error());
	$tishi='';
	

 
 
 
 
 
 

while($mot_array = mysql_fetch_array($mot_result)){
$code=$mot_array['id_departement'];
/////departement*************************************
$de_sql = "SELECT * FROM departement WHERE code like '$code' ";
$de_result = mysql_query($de_sql);
if(!$de_result) exit('fail&nbsp;'.mysql_error());
$de_array = mysql_fetch_array($de_result);
 $departement=$arr_suzu[$de_array['daima']];
 
 
	
	if($mot_array['nom'])$tishi.='<li class="cshiname"><a href="ville.php?v='.$mot_array['nom'].'&c='.$mot_array['cp'].'&d='.$code.'#ville-ex" class="a1" >'.$mot_array['nom'].'('.$mot_array['cp'].') '.$departement.' </a></li>';
 	
 	
	
	}
 
 if(!$tishi)$_POST['k']=" Aucune ville correspondant à votre recherche n'a été trouvée.";else $_POST['k']=$tishi;
 
 
 
 
 
 
 
 
 
 
 
 echo json_encode($_POST);



?>