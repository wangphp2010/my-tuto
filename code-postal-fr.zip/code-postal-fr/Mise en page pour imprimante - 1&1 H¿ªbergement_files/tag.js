//05-12-2013 15:12:56
var journeycode='c0f3f51c-1cbe-4f4b-94b5-4936d92bb02f';

var captureConfigUrl ='rcs.veinteractive.com/CaptureConfigService.asmx/CaptureConfig';

var chatServicesUrl ='rcs.veinteractive.com/ConversationService.asmx/';

var veHostDomain="//config1.veinteractive.com";

(function() { 
 var ve = document.createElement('script'); 
 ve.type = 'text/javascript'; 
 ve.async = true; 
 ve.src = ('https:' == document.location.protocol ? 'https://' : 'http://') + 'config1.veinteractive.com/tags/c0f3f51c/1cbe/4f4b/94b5/4936d92bb02f/vecapture.js'; 
 var s = document.getElementsByTagName('script')[0];s.parentNode.insertBefore(ve, s);

}) ();