var NSfTIF=window.NSfTIF||{};NSfTIF.cnr=2751;NSfTIF.pid=403;NSfTIF.reset=function(){NSfTIF.origin="NSfTIF";NSfTIF.pType="CP";
NSfTIF.section="undef/undef";NSfTIF.tax_id="1";NSfTIF.cr="";NSfTIF.sktg="Diverse/Diverse/Diverse";NSfTIF.keyword="";NSfTIF.cc="de";
NSfTIF.rc="de";NSfTIF.mandant="uid";NSfTIF.pTypeUid="AP";NSfTIF.frabo=true;NSfTIF.has_ads=true;NSfTIF.options={}};NSfTIF.reset();
NSfTIF.uidPixeltypeList={AP:"AP",CP:"CP",NP:"NP",SP:"SP",XP:"XP"};NSfTIF.sectionList={"/produkte/dslupgrade-de/":"89","/produkte/mobileorder-de/":"89","/produkte/mobile-contractshop-de/":"89","/produkte/hosting-order-de/":"281","/produkte/eue-home/":"89","/produkte/m.eue-home/":"89","/produkte/dslcancel-de/":"89","/produkte/dslorder-de/":"89","/produkte/m.mobileorder-de/":"89","/produkte/hostupgrade-de/":"89","/produkte/diy-business-de/":"89","/produkte/contract-de/":"89","/produkte/":"89"};
NSfTIF.keywordMapping={};NSfTIF.sectionListOewa={};NSfTIF._mapPgId2ContentClass=function(a){if(this._isDef(this.sectionList[a])){return this.sectionList[a]
}else{return this._getIdCode()}return""};NSfTIF._validateSection=function(a){a="/"+String(a).toLowerCase()+"/";a=a.replace(/\/\//g,"/");
return a.substr(1,a.length-2)};NSfTIF._setPTypeUid=function(a){if(this._isDef(this.uidPixeltypeList[a])){this.pTypeUid=a}else{this.pTypeUid="XP"
}};NSfTIF._setSection=function(a){this.section=this._validateSection(a)};NSfTIF._getIdCode=function(){var a="/"+this.section+"/";
var b=a.length;for(var c in this.sectionList){if(b>=c.length&&a.substr(0,c.length)==c){this.tax_id=this.sectionList[c];break
}}return this.tax_id};NSfTIF._loadPixel=function(a){if(a){(new Image()).src=a}};NSfTIF._mapPgId2SKTG=function(a){if(this._isDef(this.sectionListOewa[a])){return this.sectionListOewa[a]
}else{return this._getIdCodeOewa()}return""};NSfTIF._getIdCodeOewa=function(){var a="/"+this.section+"/";var b=a.length;for(var c in this.sectionListOewa){if(b>=c.length&&a.substr(0,c.length)==c){this.sktg=this.sectionListOewa[c];
break}}return this.sktg};NSfTIF._replaceVariables=function(a){a=a.replace(/__SC__/g,this.section);a=a.replace(/__TYPE__/g,this.pType);
a=a.replace(/__CODE__/g,this.tax_id);a=a.replace(/__SKTG__/g,this.sktg);a=a.replace(/__CRG__/g,this.cr);a=a.replace(/__CR__/g,this.cr);
a=a.replace(/__CC__/g,this.cc);a=a.replace(/__REGION__/g,this.rc);a=a.replace(/__R__/g,escape(document.referrer));a=a.replace(/__D__/g,this._getRandom());
a=a.replace(/__MAND__/g,this.mandant);a=a.replace(/__UIDPTYPE__/g,this.pTypeUid);a=a.replace(/__CNR__/g,this.cnr);a=a.replace(/__PID__/g,this.pid);
a=a.replace(/__ORIGIN__/g,this.origin);for(var b in this.options){a=a.replace(new RegExp("__"+b.toUpperCase()+"__","g"),this.options[b])
}a=a.replace(/__[A-Z_]+__/g,"");return a};NSfTIF._rvmv=function(a){for(key in a){a[key]=NSfTIF._replaceVariables(a[key])}return a
};NSfTIF._isDef=function(b){return typeof(b)!="undefined"};NSfTIF.init=function(a){if(!this._isDef(a)){return}if(typeof a.frabo=="boolean"){this.frabo=a.frabo
}if(typeof a.has_ads=="boolean"){this.has_ads=a.has_ads}if(a.ptypeuid){this._setPTypeUid(a.ptypeuid)}if(a.cr){this.cr=a.cr
}if(a.cc){this.cc=a.cc.toLowerCase()}if(a.region){this.rc=a.region.toLowerCase()}this.initUniv(a);if(a.pageidentifier){this._setSection(a.pageidentifier);
var b=this._mapPgId2ContentClass(this.section);if(b!=""){this.tax_id=b}b=this._mapPgId2SKTG(this.section);if(b!=""){this.sktg=b
}}if(a.contentclass){this.tax_id=a.contentclass}if(a.sktg){this.sktg=a.sktg}};NSfTIF.initUniv=function(a){if(a){for(var b in a){if(b.match(/^[a-z_]+$/i)){this.options[b]=a[b]
}}}};NSfTIF.checkFraBo=function(){return this.frabo&&window.location.protocol=="http:"&&document.readyState!="complete"};
NSfTIF.rlsTrc=function(a){this._loadPixel(this._replaceVariables(a))};NSfTIF.rlsTrcRed=function(a){window.location=this._replaceVariables(a)
};NSfTIF._trim=function(a){return a.replace(/\s+$/,"").replace(/^\s+/,"")};NSfTIF._getRandom=function(){return Math.round(Math.random()*100000)
};NSfTIF.tifInit=function(a){if(a){this.init(a)}if(typeof NSfTIF.track==="function"){NSfTIF.track()}};NSfTIF.track=function(a){if(a){this.init(a)
}this.rlsTrc("//pixelbox.uimserv.net/cgi-bin/1und1_shop/__TYPE__/__CODE__;sc%3D__SC__%26salesarea%3D__SALESAREA__%26brand%3D1und1%26region%3D__REGION__%26dclass=classic%26cr%3D__CR__%26uid_debug%3D__UID_DEBUG__%26eueid%3D__EUEID__%26hid%3D__HID__?d%3D__D__%26r=__R__");
if((NSfTIF.cc==="de"||NSfTIF.rc==="de")&&window.location.protocol==="http:"&&document.readyState!=="complete"&&NSfTIF.options.pageidentifier!=="produkte/eue-home/Home/Start page"){szmvars=NSfTIF._replaceVariables("1und1//__TYPE__//__CODE__");
NSfTIF._writeJS("http://1und1.ivwbox.de/2004/01/survey.js?d="+NSfTIF._getRandom())}if(!NSfTIF._isDef(NSfTIF.options.has_ads)||NSfTIF.options.has_ads){if(this.cc=="de"&&this.rc=="de"){this.rlsTrc("//1und1.ivwbox.de/cgi-bin/ivw/__TYPE__/__CODE__;?r=__R__%26d%3D__D__")
}}this.rlsTrc("//uidbox.uimserv.net/cgi-bin/__MAND__/__UIDPTYPE__/agof=__CODE__&sc=__SC__&evtid=__EVTID__&haID=__HAID__&mediaID=__MEDIAID__&mpID=__MPID__&tpvID=__TPVID__&tid=__TID__&site=__SITEID__&region=__REGION__&lpos=__LPOS__&tc=__TC__&item_id=&item_ct=&item_pr=__ITEMPR__&extEvtID=__EXTEVTID__&tm=__TM__?r=__R__&d=__D__")
};NSfTIF._loadJavaScript=function(b){var a=document.createElement("script");a.setAttribute("type","text/javascript");a.setAttribute("src",b);
if(document.head){document.head.appendChild(a)}};NSfTIF._writeJS=function(a){document.write('<script type="text/javascript" src="'+a+'"><\/script>')
};if(!window.UIM){window.UIM={}}UIM.uim_init={};UIM.init=function(a){if(a){UIM.uim_init=a}};UIM.Pageview=function(a){NSfTIF.origin="UIM";
if(typeof(a)=="undefined"){NSfTIF.track(UIM.uim_init)}else{if(!a.site&&UIM.uim_init.site){a.site=UIM.uim_init.site}if(!a.pageidentifier&&a.section){a.pageidentifier=a.section
}NSfTIF.track(a)}NSfTIF.origin="NSfTIF"};var TIF={tifInit:function(a){NSfTIF.origin="TIF";NSfTIF.track(a);NSfTIF.origin="NSfTIF"
}};var SMV={smvInit:function(a){NSfTIF.origin="SMV";NSfTIF.track(a);NSfTIF.origin="NSfTIF"}};