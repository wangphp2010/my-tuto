<?php

header("content-type:text/html;charset=utf-8");

require("commun/codeconn.php");

$code=$_GET['d'];

 
 
$de_sql = "SELECT * FROM db508556084.ville WHERE id_departement LIKE '$code'  ";
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
$de_result = mysql_query($de_sql);
if(!$de_result) exit('fail&nbsp;'.mysql_error());
while($de_array = mysql_fetch_array($de_result)){
	echo $de_array[id_ville]," ",$de_array[nom],' ',$de_array[cp],'<br />';}
	
	
	?>