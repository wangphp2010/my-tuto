<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

<?php
 


$a='Aspremont 05140 ';

$nom=trim(preg_replace('#\d#','',$a));
$cp=trim(preg_replace('#\D#','',$a));

 
echo $cp





?>