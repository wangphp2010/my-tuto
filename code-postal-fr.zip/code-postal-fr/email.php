<?


require("function.php");
if(get_client_ip()!='82.237.83.106'&&get_client_ip()!='2a01:e35:2ed5:36a0:bce2:9560:d0d9:89b5')exit();
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" 
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta http-equiv="content-language"		content="fr"			/>
<meta name="copyright"		content="http://code-postal-fr.net" />
<meta name="classification"	content="code postal,codes postaux,courrier,poste" />

<meta name="content"		content="Code postal villes : cherchez le code postal d'une ville ou l'inverse parmi 36000 villes et trouvez aussi des suggestions de sites internet locaux (entreprises, loisirs, tourisme, etc.) ainsi qu'une carte de chaque ville." />
    
<meta name="description" content="Code postal villes : cherchez le code postal d'une ville ou l'inverse parmi 36000 villes et trouvez aussi des suggestions de sites internet locaux (entreprises, loisirs, tourisme, etc.) ainsi qu'une carte de chaque ville." />	 
	<meta name="expires"		content="never" />
      
<meta name="keywords" content="codespostaux, codes, postaux, code, postal, recherche, ville, france, rechercher, info, fr, departement, departements, gratuit, service, rechercher, codepostal, code-postal, codes-postaux, code postal, codes postaux, ville francaise" />


<title>Code postal . Tous les codes postaux de France</title>
 
<link href="css.css" rel="stylesheet" type="text/css" />
</head>

<body>
<?php require("head.php");?>

<div><a href="emaillook.php">查看邮件</a></div>
<form name="myform" id="form1" enctype="multipart/form-data" method="post" action="emailfaa.php" onSubmit="return InputCheck(this)" >
<div><br>
收件人:<br />
guhu2019@hotmail.fr<br />
yanick2019@yahoo.fr
<br /> 
<textarea style= "width:499px;height:320px;background: url(tu/text.jpg) no-repeat  center;" name="email" class="wenbenyu" id="neirong"></textarea><br />
发件人: <input name="email_send" type="text"  class="STYLE11" id="email_send"   size="30" />
<br /><input type="submit" name="submit"  class="tijiaoanniuziti" value="envoyer" />
<br />
<input  type="checkbox"name="send"  class="tijiaoanniuziti" value="sendonly" />发送
  <br />     
   
<input  type="checkbox"name="sauvegarde"  class="tijiaoanniuziti" value="sendonly" />存入
<br />
 <input  type="checkbox"name="supprimer"  class="tijiaoanniuziti" value="sendonly" />清除
<br />
 
  
  
                                 <textarea style= "width:499px;height:320px;background: url(tu/text.jpg) no-repeat  center;" name="neirong" class="wenbenyu" id="neirong"></textarea>
  </div>
	<br>					  				 
				  	  
				<div >  <input type="submit" name="submit"  class="tijiaoanniuziti" value="envoyer" />        </div>	
   
</form>

</body></html>