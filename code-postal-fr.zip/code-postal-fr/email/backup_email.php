<?
session_start();

require ("../commun/codeconn.php");
 
if(!$_SESSION['admin'])exit;


header("Content-type:text/html;charset=utf-8");

$repete=200;//每几条循环insert


$to_file_name = date("d-m-Y", time()) . ".sql";

$fh = fopen($to_file_name, "w"); //创建文件
fclose($fh);



 
 

$value="email_non_pub";


 
$file='';

    $show_create_table = mysql_query("SHOW  CREATE TABLE $value");
	if(!$show_create_table)exit(mysql_error());
    $show_create_table_sql = mysql_fetch_array($show_create_table);
	$file .= "--\r\n";
    $file .= "-- 表的结构 `$value`\r\n";
    $file .= "--\r\n\r\n";
    $file .= $show_create_table_sql['Create Table'] . ";";  



$insert = "\r\n\r\n\r\nINSERT INTO `$value` (";

    $result = mysql_query("SELECT * FROM db508556084.$value   ");
    $gb_array = mysql_fetch_array($result);
    if ($gb_array) {

        $s = 0;
        $num_k = count($gb_array);
        foreach ($gb_array as $k => $v) {
            $s++;
            if ($s == $num_k) {
                if (!is_numeric($k))
                    $insert .= "`$k`";
            } else {
                if (!is_numeric($k))
                    $insert .= "`$k`,";
            }

        }//39

         $insert.=")VALUES\r\n";
        
		$file .= $insert;


         $count_result = mysql_query("SELECT count(*) FROM db508556084.$value   ");
        $count_array = mysql_fetch_array($count_result);
        $num = $count_array['count(*)'];

        $result = mysql_query("SELECT * FROM db508556084.$value  ORDER BY id ");
        $t = 0;$d=0;
  $file .= "\r\n";

      

        while ($gb_array = mysql_fetch_array($result)) {
            $t++;$d++;


            $i = 0;
            $cout_suju = count($gb_array);
            $file .= "( ";
            foreach ($gb_array as $k => $v) {

                $i++;
                $v = str_replace("'", "''", $v);
                $v = str_replace('\\', '\\\\', $v);
                $v = str_replace('"', '""', $v);
                $v = str_replace("\r\n", '\r\n', $v);
                $v = str_replace("\n", '\n', $v);
                $v = str_replace("\r", '\r', $v);


                if (!is_numeric($k)) {
                    if ($num <= $repete) {
                        
						if ($i < $cout_suju) {
                                  $file .= "'$v',";
                        } else {
                            if ($t < $num) {
                                 $file .= "'$v'),\r\n";
                            } else {
                                 $file .= "'$v');\r\n";
                            }
                        }


                    } else {
                        if ($t <= $repete) {
                            if ($i < $cout_suju) {
                                  $file .= "'$v',";
                            } else {
                                  if($d<$num)$file .= "'$v'),\r\n";else $file .= "'$v');\r\n";
                            }
                        } else {
                            if ($t ==$repete+1) {
                                if ($i < $cout_suju) {
                                    $file .= "'$v',";
                                } else {
                                     $file .= "'$v');\r\n";
                                    $file .= $insert;
                                    $t = 0;
                                }
                            }
                        }
                    }
                }


            }


       

		}

       


    }else{ echo "34kong<br>";exit;}

  $file .= "\r\n\r\n\r\n\r\n";

        $fh = fopen($to_file_name, "a");
        fwrite($fh, $file);
        fclose($fh);  
    mysql_free_result($result);


    $fh = 'email_non_pub-'.date("d-m-Y", time()) . ".sql";
    set_time_limit(0); //防止下载超时

    header("Content-Type: application/force-download/sql"); //强制弹出保存对话框
    header("Pragma: no-cache"); // 缓存
    header("Expires: 0");
    header("Content-Transfer-Encoding: binary");
    // header("Content-Length: ".$filesize); //文件大小
    header('Content-Disposition: attachment; filename="' . basename($fh) . '"'); //文件名


    ob_clean();
    flush();
    readfile($to_file_name);
    unlink($to_file_name);
 

 


?> 

 