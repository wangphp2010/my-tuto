<?php
session_start();

  
 
 if($_POST['submit']){
	if($_POST['pa']=='ab12345678'){$_SESSION['admin']=1;} }
 if(!$_SESSION['admin'])exit(' <form action="" method="post"><input  name="pa"  type="text"/>  <input  type="submit"  name="submit"  value="denglu"/>
    </form>');
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
 <!-- Mimic Internet Explorer 7 -->
<meta http-equiv="X-UA-Compatible" content="IE=EmulateIE7" />
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />


 
 
<meta name="language" content="FR" />
<meta name="site-languages" content="French" />
<meta name="Content-Language" content="fr-FR" />

  




<style type="text/css">
<!--
.beijin {background-color: #dddddd;}
.STYLE12 {font-size: 20px}
-->
</style>
</head>

<body>
 
<form name="myform" id="form1" enctype="multipart/form-data" method="post" action="emails.php?email=123456789" onSubmit="return InputCheck(this)" >
<div><br>http://monpub.com/genxin.php?action=sauve_email_non_pub&mail=
<br />
收件人:<br />
guhu2019@hotmail.fr<br />
yanick2019@yahoo.fr
<br /> 
<textarea style= "width:499px;height:320px;background: url(tu/text.jpg) no-repeat  center;" name="email" class="wenbenyu" id="neirong"></textarea> 
<br /><input type="submit" name="submit"  class="tijiaoanniuziti" value="envoyer" />
<br />
<input  type="checkbox"name="send"  class="tijiaoanniuziti" value="sendonly"    checked="checked"/>发送
  <br />  <br />
 

<a href="backup_email.php?email=123456789">备份不用发送的email</a>
<br />
 <br />

   
   
<br />
  
                                
  </div><br /><br />

	 					  				 
				  	  
				<div ></div>	
   
</form>
<br />

<textarea style="width:1200px; height:800px;">
<?php 
 require('../commun/codeconn.php');
$query_sql="SELECT * FROM db508556084.email_non_pub WHERE 1 ORDER BY id DESC ";	 
$result = mysql_query($query_sql);
if(!$result) exit('fail&nbsp;'.mysql_error());
$s=0;
while($gb_array = mysql_fetch_array($result)){
	$s++;
	echo $gb_array['email']," ip :",$gb_array['ip'],"  [",$gb_array['systeme'],"] ",date("d-m-Y H:i:s",$gb_array['time']),"\r\n\r\n";
	
}
echo 'total : ',$s;
 ?></textarea>
 
</body></html>