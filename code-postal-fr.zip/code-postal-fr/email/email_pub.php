<?php 
$email_pub='

  
  Sur monpub.com vous pouvez deposer et remonter votre annonce gratuitement.
 
 <div style="font-family:"Times New Roman", Times, serif;"><div style="border:solid 2px #CCCCCC;"><div style="padding:5px;"><strong>
<a href="http://monpub.com/" >www.monpub.com</a><br /><br /> '.
"Site d'annonces d'offres et de demandes, permettant de publier des annonces dans le secteur immobilier, l'emploi, l'automobile, les fonds de commerce ou pas de porte, Mon Pub propose les annonces des vendeurs, des prestataires de services, des professeurs de cours particuliers, les annonces de vente, de location immobilière, appartement, fond de commerce, sur toute la France, Paris et Province 
annonces fond de commerce,immobilier, voiture, moto,rencontre,produits d'occasion, locations de vacances, offres d'emploi, services de proximité, animaux ...<br /><br />---l'équipe monpub.com---</div></div></div> ";
?>