<?php
session_start();
header("content-type:text/html;charset=utf-8");

if(!$_SESSION['admin'])exit;

require('email_pub.php');
require('../commun/codeconn.php');
 
 
 
$addr_send='monpub@monpub.com';

if(!isset($_POST['submit'])){
    exit('
	<head><style type="text/css">
<!--
.STYLE1 {font-family: "Times New Roman", Times, serif; font-weight: bold; font-size: 30px; }
-->
</style>
</head>
	<table width="978" border="0" cellpadding="0" cellspacing="0" align="center">

  
  <tr>
    <td width="190" height="90" ><a href="http://www.monpub.com/"><img src="tu/monpub.jpg" width="190" height="90" border="0" /></a></td>
    <td width="788"></td>
  </tr>
</table>
<div  align="center">
<p class="STYLE1"><a href="http://www.monpub.com/">fail</a></p>

</div>');
}



  
$SN = $_SERVER['SERVER_NAME'];
if (substr($_SERVER['HTTP_REFERER'], 7, strlen($SN))!=$SN&&substr($_SERVER['HTTP_REFERER'], 11, strlen($SN))!=$SN) exit('stop');//防止跨域提交





if($_POST['neirong']){
$neirong=htmlspecialchars(trim($_POST['neirong']));
$neirong.=$email_pub;}
else { $neirong=$email_pub;}

 
if($_POST['email'])
{
$email=trim($_POST['email']);
$arr = explode("\n",$email);

foreach($arr   as   $key=>$val){   if(empty($arr[$key]))   unset($arr[$key]);    }//去除空数组


function trim_value(&$value,$key) {$value=trim($value);}array_walk($arr,"trim_value");//去除数组值的前后空格


$arr=array_values(array_unique($arr)); //去除重复数组
//去除重复数组 $arr=array_values(array_flip(array_flip($arr))); 




$sauvegarde=$_POST['sauvegarde'];
$send=$_POST['send'];
$supprimer=$_POST['supprimer'];
$supprimer_invalide=$_POST['supprimer_invalide'];
$sauve_email_invalide=$_POST['sauve_email_invalide'];











//*****************************************************************
//*****************************************************************
//*****************************************************************
//*****************************************************************
//*****************************************************************
//*****************************************************************
//*****************************************************************
//*****************************************************************
//*****************************************************************
//*****************************************************************

//*****************************************************************
 

 
 
//*****************************************************************
//*****************************************************************
//*****************************************************************
//*****************************************************************
//*****************************************************************
//*****************************************************************
//*****************************************************************
//*****************************************************************



















 







if($send){////发送

for($t=0;$t<=count($arr);$t++){
 
$arr_ee=strtolower(trim($arr[$t]));
 

$date = date("d-m-Y H:i", time());
$header  = 'MIME-Version: 1.0' . "\r\n";
$header .= 'Content-type: text/html; charset=utf-8' . "\r\n";
$header .= "To: $arr_ee \r\n";
$header .= "From: $addr_send". "\r\n";
$subject = " !! Annonce gratuite"; 
$subject = "=?UTF-8?B?".base64_encode($subject)."?=";
$content = nl2br($neirong);
$content .='<br /><br /><br /><br /><br /><strong><a href="http://monpub.com/genxin.php?action=sauve_email_non_pub&mail='.$arr_ee.'" target="_blank" style="color:#000;text-decoration:none;" >Ne plus recevoir cette mail</a></strong>';

$content .= " ".$date;


 if($arr_ee){
	
$query_sql="SELECT * FROM db508556084.email_non_pub WHERE 1 AND email like '$arr_ee' ";	 
$result = mysql_query($query_sql);
if(!$result) exit('fail&nbsp;'.mysql_error());
$gb_array = mysql_fetch_array($result);
	 
	 
if(!$gb_array){
	
	
if(mail($arr_ee, $subject, $content, $header))echo "$arr_ee 发送成功<br /><br />";else echo "$arr_ee <font color=red>发送失败 ".mysql_error()."</font> *****************<br /><br />";
 
 
 
 }else{echo "$arr_ee <font color=red>不用发送</font> *****************<br /><br />";}
 sleep(2);
}

}
echo '发送完毕<br>';
}


 
 



}
else//没有输入邮件时
{ echo 'cuowu';exit ;}





?>