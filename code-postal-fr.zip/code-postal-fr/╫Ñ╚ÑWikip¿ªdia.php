<?php
header("content-type:text/html;charset=utf-8");

$a='
<table class="infobox_v2" cellspacing="7">
<tr>
<td colspan="2" class="entete map" style="background-color:#DDFFDD;color:#000000"><b>Francheleins</b></td>
</tr>
<tr>
<td colspan="2" style="text-align:center; line-height: 1.5em;"><a href="/wiki/Fichier:Town_hall_of_Francheleins_-_2.JPG" class="image"><img alt="La mairie de Francheleins." src="//upload.wikimedia.org/wikipedia/commons/thumb/c/c8/Town_hall_of_Francheleins_-_2.JPG/280px-Town_hall_of_Francheleins_-_2.JPG" width="280" height="210" srcset="//upload.wikimedia.org/wikipedia/commons/thumb/c/c8/Town_hall_of_Francheleins_-_2.JPG/420px-Town_hall_of_Francheleins_-_2.JPG 1.5x, //upload.wikimedia.org/wikipedia/commons/thumb/c/c8/Town_hall_of_Francheleins_-_2.JPG/560px-Town_hall_of_Francheleins_-_2.JPG 2x" /></a><br />
La mairie de Francheleins.</td>
</tr>
<tr>
<th colspan="2" style="text-align:center;background-color:#DDFFDD;color:#000000">Administration</th>
</tr>
<tr>
<th scope="row"><a href="/wiki/Liste_des_pays_du_monde" title="Liste des pays du monde">Pays</a></th>
<td><span class="datasortkey" data-sort-value="France"><span class="flagicon"><a href="/wiki/Fichier:Flag_of_France.svg" class="image" title="Drapeau de la France"><img alt="Drapeau de la France" src="//upload.wikimedia.org/wikipedia/commons/thumb/c/c3/Flag_of_France.svg/20px-Flag_of_France.svg.png" width="20" height="13" class="thumbborder" srcset="//upload.wikimedia.org/wikipedia/commons/thumb/c/c3/Flag_of_France.svg/30px-Flag_of_France.svg.png 1.5x, //upload.wikimedia.org/wikipedia/commons/thumb/c/c3/Flag_of_France.svg/40px-Flag_of_France.svg.png 2x" /></a>&#160;</span><a href="/wiki/France" title="France">France</a></span></td>
</tr>
<tr>
<th scope="row"><a href="/wiki/R%C3%A9gion_fran%C3%A7aise" title="Région française">Région</a></th>
<td><a href="/wiki/Rh%C3%B4ne-Alpes" title="Rhône-Alpes">Rhône-Alpes</a></td>
</tr>
<tr>
<th scope="row"><a href="/wiki/D%C3%A9partement_fran%C3%A7ais" title="Département français">Département</a></th>
<td><a href="/wiki/Ain_(d%C3%A9partement)" title="Ain (département)">Ain</a></td>
</tr>
<tr>
<th scope="row"><a href="/wiki/Arrondissement_fran%C3%A7ais" title="Arrondissement français">Arrondissement</a></th>
<td><a href="/wiki/Arrondissement_de_Bourg-en-Bresse" title="Arrondissement de Bourg-en-Bresse">Bourg-en-Bresse</a></td>
</tr>
<tr>
<th scope="row"><a href="/wiki/Canton_fran%C3%A7ais" title="Canton français">Canton</a></th>
<td><a href="/wiki/Canton_de_Saint-Trivier-sur-Moignans" title="Canton de Saint-Trivier-sur-Moignans">Saint-Trivier-sur-Moignans</a></td>
</tr>
<tr>
<th scope="row"><a href="/wiki/Intercommunalit%C3%A9_en_France" title="Intercommunalité en France">Intercommunalité</a></th>
<td><a href="/wiki/Communaut%C3%A9_de_communes_Montmerle_Trois_Rivi%C3%A8res" title="Communauté de communes Montmerle Trois Rivières">Communauté de communes Montmerle Trois Rivières</a></td>
</tr>
<tr>
<th scope="row"><a href="/wiki/Maire_(France)" title="Maire (France)">Maire</a><br />
<a href="/wiki/Mandat_politique" title="Mandat politique">Mandat</a></th>
<td>Irène Leclerc<br />
<a href="/wiki/2008" title="2008">2008</a>-<a href="/wiki/2014" title="2014">2014</a></td>
</tr>
<tr>
<th scope="row"><a href="/wiki/Code_postal" title="Code postal">Code postal</a></th>
<td>01090</td>
</tr>
<tr>
<th scope="row"><a href="/wiki/Code_officiel_g%C3%A9ographique#Code_commune" title="Code officiel géographique">Code commune</a></th>
<td>01165</td>
</tr>
<tr>
<th scope="col" colspan="2" style="text-align:center;background-color:#DDFFDD;color:#000000">Démographie</th>
</tr>
<tr>
<th scope="row"><a href="/wiki/Chiffres_de_population_de_la_France" title="Chiffres de population de la France">Population<br />
municipale</a></th>
<td><span class="nowrap">1&#160;370&#160;<abbr class="abbr" title="habitants">hab.</abbr></span> <small>(2011)</small></td>
</tr>
<tr>
<th scope="row" style="vertical-align: bottom"><a href="/wiki/Densit%C3%A9_de_population" title="Densité de population">Densité</a></th>
<td><span class="nowrap">101&#160;hab./km<sup>2</sup></span></td>
</tr>
<tr>
<th scope="col" colspan="2" style="text-align:center;background-color:#DDFFDD;color:#000000">Géographie</th>
</tr>
<tr>
<th scope="row"><a href="/wiki/Coordonn%C3%A9es_g%C3%A9ographiques" title="Coordonnées géographiques">Coordonnées</a></th>
<td><span class="plainlinksneverexpand"><a class="external text" href="//tools.wmflabs.org/geohack/geohack.php?pagename=Francheleins&amp;language=fr&amp;params=46.0744444444_N_4.80916666667_E_type:city_region:FR"><span class="geo-default"><span class="geo-dms" title="Cartes, vues aériennes et autres données pour cet endroit"><span class="latitude">46°&#160;04′&#160;28″&#160;Nord</span> <span class="longitude">4°&#160;48′&#160;33″&#160;Est</span></span></span><span class="geo-multi-punct">﻿ / ﻿</span><span class="geo-nondefault"><span class="geo-dec" title="Cartes, vues aériennes et autres données pour cet endroit">46.0744444444, 4.80916666667</span><span style="display:none">﻿ / <span class="geo">46.0744444444; 4.80916666667</span></span></span></a></span><span style="font-size: small;"><span id="coordinates"><span class="plainlinksneverexpand"><a class="external text" href="//tools.wmflabs.org/geohack/geohack.php?pagename=Francheleins&amp;language=fr&amp;params=46.0744444444_N_4.80916666667_E_type:city_region:FR"><span class="geo-default"><span class="geo-dms" title="Cartes, vues aériennes et autres données pour cet endroit"><span class="latitude">46°&#160;04′&#160;28″&#160;N</span> <span class="longitude">4°&#160;48′&#160;33″&#160;E</span></span></span><span class="geo-multi-punct">﻿ / ﻿</span><span class="geo-nondefault"><span class="geo-dec" title="Cartes, vues aériennes et autres données pour cet endroit">46.0744444444, 4.80916666667</span><span style="display:none">﻿ / <span class="geo">46.0744444444; 4.80916666667</span></span></span></a></span></span></span>&#160;&#160;</td>
</tr>
<tr>
<th scope="row"><a href="/wiki/Altitude" title="Altitude">Altitude</a></th>
<td>Min.&#160;<span class="nowrap">209&#160;m</span>&#160;– Max.&#160;<span class="nowrap">269&#160;m</span></td>
</tr>
<tr>
<th scope="row"><a href="/wiki/Superficie" title="Superficie">Superficie</a></th>
<td><span class="nowrap">13,56&#160;km<sup>2</sup></span></td>
</tr>
<tr>
<td></td>
</tr>
<tr>
<th scope="col" colspan="2" style="text-align:center;background-color:#DDFFDD;color:#000000">Localisation</th>
</tr>
<tr>
<td colspan="3" align="center">
<div class="img_toogle">
<div class="geobox">
<p><small>Géolocalisation sur la carte&#160;: <a href="/wiki/Ain_(d%C3%A9partement)" title="Ain (département)">Ain</a></small></p>
<table class="DebutCarte" border="0" cellspacing="0" cellpadding="0" style="margin:0;border:none;padding:0;text-align:center">
<tr>
<td style="border:none;padding:0">
<div style="position:relative;;margin:auto"><a href="/wiki/Fichier:01-Ain-d%C3%A9partement-fr-carte-A1.svg" class="image" title="Voir sur la carte administrative d'.   "'Ain " .'"><img alt="Voir sur la carte administrative d'.   "'Ain " .'" src="//upload.wikimedia.org/wikipedia/commons/thumb/7/77/01-Ain-d%C3%A9partement-fr-carte-A1.svg/280px-01-Ain-d%C3%A9partement-fr-carte-A1.svg.png" width="280" height="254" srcset="//upload.wikimedia.org/wikipedia/commons/thumb/7/77/01-Ain-d%C3%A9partement-fr-carte-A1.svg/420px-01-Ain-d%C3%A9partement-fr-carte-A1.svg.png 1.5x, //upload.wikimedia.org/wikipedia/commons/thumb/7/77/01-Ain-d%C3%A9partement-fr-carte-A1.svg/560px-01-Ain-d%C3%A9partement-fr-carte-A1.svg.png 2x" /></a>
<div style="position:absolute;top:47.770768814887%;left:5.7058116127396%;width:0px;height:0px;margin:0;padding:0;line-height:0px;background-color:transparent;">
<div style="position:relative;top:-8px;left:-8px;width:16px;height:16px;background-color:transparent;"><a href="/wiki/Fichier:City_locator_14.svg" class="image"><img alt="City locator 14.svg" src="//upload.wikimedia.org/wikipedia/commons/thumb/5/5d/City_locator_14.svg/16px-City_locator_14.svg.png" width="16" height="16" srcset="//upload.wikimedia.org/wikipedia/commons/thumb/5/5d/City_locator_14.svg/24px-City_locator_14.svg.png 1.5x, //upload.wikimedia.org/wikipedia/commons/thumb/5/5d/City_locator_14.svg/32px-City_locator_14.svg.png 2x" /></a></div>
<div style="position:relative;top:-16px;">
<div style="font-size:90%;position:relative;top:-1.65em;left: 0.5em;text-align:left;width:12em;line-height:1.2em;"><span class="toponyme">Francheleins</span></div>
</div>
</div>
</div>
</td>
</tr>
</table>
';








$url = "http://fr.wikipedia.org/wiki/Amareins"; 
$ch = curl_init(); 
$timeout = 5; 
curl_setopt($ch, CURLOPT_URL, $url); 
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1); 
curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, $timeout); 
//在需要用户检测的网页里需要增加下面两行 
//curl_setopt($ch, CURLOPT_HTTPAUTH, CURLAUTH_ANY); 
//curl_setopt($ch, CURLOPT_USERPWD, US_NAME.":".US_PWD); 
$contents = curl_exec($ch); 
curl_close($ch); 
$a=$contents;



  


$trianle1="#\<[^>]+\>#";

$trianle2="#\<\/\w+\>#";


//<td colspan="3" align="center">


$a=preg_replace($trianle1,'',$a);

$a=preg_replace($trianle2,'',$a);


//echo $a;
 
 



preg_match("#Région\s.+#", $a, $m);
foreach($m as $val){echo $val,'<br /><br />';}





preg_match("#Département\s.+#", $a, $m);
foreach($m as $val){echo $val,'<br /><br />';}




preg_match("#Arrondissement\s.+#", $a, $m);
foreach($m as $val){echo $val,'<br /><br />';}

  

preg_match("#Canton\s.+#", $a, $m);
foreach($m as $val){echo $val,'<br /><br />';}



preg_match("#Code postal\s.+#", $a, $m);
foreach($m as $val){echo $val,'<br /><br />';}



preg_match("#Code commune\s.+#", $a, $m);
foreach($m as $val){echo $val,'<br /><br />';}


preg_match("#Population
municipale\s.+#", $a, $m);
foreach($m as $val){echo $val,'<br /><br />';}

//*****//**************************
preg_match("#Densité\s.+#", $a, $m);foreach($m as $val){echo $val,'<br /><br />';}

preg_match("#Coordonnées\s.+#", $a, $m);foreach($m as $val){
 	
	
	preg_match("#\/[^/]+\/#", $val, $ms);
foreach($ms as $vals){
	echo "Coordonnées ",trim(str_replace("/",'',$vals)),'<br /><br />';}
}



preg_match("#Superficie\s.+#", $a, $m);foreach($m as $val){echo $val,'<br /><br />';}



?>