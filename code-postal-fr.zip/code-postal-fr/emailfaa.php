<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<?
require('email_pub.php');



$addr_send='sehui303@mail.com';

if(!isset($_POST['submit'])){
    exit('
	');
}

require("function.php");
if(get_client_ip()!='82.237.83.106')exit();
 
$SN = $_SERVER['SERVER_NAME'];
if (substr($_SERVER['HTTP_REFERER'], 7, strlen($SN))!=$SN&&substr($_SERVER['HTTP_REFERER'], 11, strlen($SN))!=$SN) exit('stop');//防止跨域提交





if($_POST['neirong']){
$neirong=htmlspecialchars(trim($_POST['neirong']));
$neirong.=$email_pub;}
else { $neirong=$email_pub;}

 
if($_POST['email'])
{
$email=trim($_POST['email']);
$arr = explode("\n",$email);

foreach($arr   as   $key=>$val){   if(empty($arr[$key]))   unset($arr[$key]);    }//去除空数组


function trim_value(&$value,$key) {$value=trim($value);}array_walk($arr,"trim_value");//去除数组值的前后空格


$arr=array_values(array_unique($arr)); //去除重复数组
//去除重复数组 $arr=array_values(array_flip(array_flip($arr))); 




$sauvegarde=$_POST['sauvegarde'];
$send=$_POST['send'];
$supprimer=$_POST['supprimer'];


if($sauvegarde){

//存入email**********************
for($i=0;$i<=count($arr);$i++){

$arr_e=strtolower(trim($arr[$i]));
$arr_e=strtolower(trim($arr[$i]));
$arr_e=str_replace('>','',$arr_e);
$arr_e=str_replace('<','',$arr_e);
if($arr_e){
$insert_email = "REPLACE INTO db415861577.email (email) VALUES ('$arr_e') ";
if(mysql_query($insert_email)){ 
  echo "存入email <strong>$arr_e</strong> 成功<br />";
  

}else{ echo mysql_error()." <font color=red><strong>$arr_e 失败</strong></font><br >";}



}
}
echo '存入完毕<br>';

}





//发送email********************************************
$mail_sauf[]="";
 

 
//*******************************************************


if($send){

for($t=0;$t<=count($arr);$t++){
$arr_ee=trim($arr[$t]);

$arr_e=strtolower(trim($arr[$i]));
$arr_e=str_replace('>','',$arr_e);
$arr_e=str_replace('<','',$arr_e);

$date = date("d-m-Y H:i", time());
$header  = 'MIME-Version: 1.0' . "\r\n";
$header .= 'Content-type: text/html; charset=utf-8' . "\r\n";
$header .= "To: $arr_ee \r\n";
$header .= "From: $addr_send". "\r\n";
$subject = '"Nouveau site pour consulter  les infos des villes francais [code-postal-fr.net]"'; 
$subject = "=?UTF-8?B?".base64_encode($subject)."?=";
$content = nl2br($neirong);
$content .= "<br /><br />".$date;

if(!in_array($arr_ee,$mail_sauf)){//email不再mail_sauf才会发送
if($arr_ee){

if(mail($arr_ee, $subject, $content, $header))echo "$arr_ee 发送成功<br /><br />";else echo "$arr_ee <font color=red>发送失败</font> *****************<br /><br />";
sleep(2);
}}

}
echo '发送完毕<br>';
}


//删除email******************************************
if($supprimer){
  
  for($i=0;$i<=count($arr);$i++){

$arr_e=strtolower(trim($arr[$i]));
$arr_e=str_replace('>','',$arr_e);
$arr_e=str_replace('<','',$arr_e);





if(!in_array($arr_e,$mail_sauf))
{
if($arr_e){
	
	
//删除无效email 在email数据中开始*******************************************************	
$insert_email = "DELETE FROM db415861577.email WHERE email like '$arr_e' LIMIT 1";

if(mysql_query($insert_email)){ 
  echo "删除email数据库中的email <strong>$arr_e</strong> 成功<br />";
  

}else{ echo mysql_error()." <font color=red><strong>$arr_e 失败</strong></font><br >";}
//删除无效email 在email数据中结束*******************************************************


//删除无效email 在alerte数据中开始*******************************************************	
$insert_alerte = "DELETE FROM db415861577.alerte WHERE email like '$arr_e' LIMIT 1";

if(mysql_query($insert_alerte)){ 
  echo "删除alerte数据库的email <strong>$arr_e</strong> 成功<br />";
  

}else{ echo mysql_error()." <font color=red><strong>$arr_e 失败</strong></font><br >";}
//删除无效email 在email数据中结束******************************************************




//删除无效email 在reg数据中开始*******************************************************	
$insert_alerte = "DELETE FROM db415861577.reg WHERE mail like '$arr_e' LIMIT 1";

if(mysql_query($insert_alerte)){ 
  echo "删除reg数据库的email <strong>$arr_e</strong> 成功<br />";
  

}else{ echo mysql_error()." <font color=red><strong>$arr_e 失败</strong></font><br >";}
//删除无效email 在reg数据中结束******************************************************


//删除email所对应的图片及数据库开始****************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************


$query_sql = "SELECT id FROM db415861577.imo WHERE email like '$arr_e' ";//找到email所对应的annonnce号码
$result = mysql_query($query_sql);
while($gb_array = mysql_fetch_array($result)){
	
	
//删除图片开始***********************************************************************
	$tid=$gb_array[id];
   if($tid){
    $sel_image = "SELECT  pathtu  FROM db415861577.image WHERE tid =  '$tid' LIMIT 3";
     $result_sel_image = mysql_query($sel_image);
    while($gb_array_image = mysql_fetch_array($result_sel_image)){
		if($gb_array_image['pathtu']){if(unlink($gb_array_image['pathtu']))echo "删除小广告中无效email对应的图片成功<br />";else echo $gb_array_image['pathtu'],"  删除小广告中无效email对应的图片失败<br />";
}
}

	}
//删除图片结束********************************************************************************************


//删除保存图片位置的数据库开始**************************************************************************
	$del_image = "DELETE FROM db415861577.image WHERE tid = '$tid' LIMIT 3";
if(mysql_query($del_image)){ 
  echo "删除小广告中无效email对应的图片的数据库 <strong>$arr_e</strong> 成功<br />";
  
  

}else{ echo mysql_error()." <font color=red>删除小广告中无效email对应的图片的数据库  <strong>$arr_e 失败</strong></font><br >";}

//删除保存图片位置的数据库结束**************************************************************************





 }
  
  if(count($gb_array)!=1){//如果email有对应的小广告
  
  
 //删除email对应的小广告开始**************************************************************************

$insert_email = "DELETE FROM db415861577.imo WHERE email like '$arr_e' "; 
if(mysql_query($insert_email)){ 
  echo "删除email对应的小广告 <strong>$arr_e</strong> 成功<br />";
  
  

}else{ echo mysql_error()." <font color=red>删除email对应的小广告 <strong>$arr_e 失败</strong></font><br >";}

//删除email对应的小广告结束************************************************************************
echo "删除",$arr_e,"对应相关广告和图片及其数据库，和alerte 结束<br >----------------------------------------------------------<br ><br >";

  }else{echo "email无对应小广告<br ><br >";}

//删除email所对应的图片及数据库结束****************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************






}
}

}
echo '<br ><br >删除完毕';
}




}
else//没有输入邮件时
{//发送email********************************************
if($send){


//发送email********************************************

$s=0;
$email_result = mysql_query("SELECT * FROM db415861577.email ");
if(!$email_result) exit('错误&nbsp;'.mysql_error());
while($email_array = mysql_fetch_array($email_result)){

$email=$email_array['email'];
$date = date("d-m-Y à H:i", time());
$header  = 'MIME-Version: 1.0' . "\r\n";
$header .= 'Content-type: text/html; charset=utf-8' . "\r\n";
$header .= "To: $email \r\n";
$header .= 'From: monpub@monpub.com' . "\r\n";
$subject = "Merci de votre visite!!--Monpub.com"; 
$subject = "=?UTF-8?B?".base64_encode($subject)."?=";
$content = $neirong;
$content .= "<br /><br />".$date;

if(!mail($email, $subject, $content, $header))
echo "<strong>发送失败,失败的邮件:",$email,"</strong><br />";else $s++;echo "发送成功:",$email,"---",$s,"<br />";

}}}

?>