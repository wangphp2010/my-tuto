<?php
require('commun/codeconn.php');
require('commun/codeca.php');

$ville=$_GET['v'];
$codepo=$_GET['c'];
$code=$_GET['d'];


if($ville&&$codepo&&$code)
{
		//有$_GET['v'] $_GET['c']时

 
//departement*************************************************
//*********************************************************************************************************
 $c=$code;


//departement*****************************************************************************************
$de_sql = "SELECT daima,id_region FROM departement WHERE code like '$c' ";
$de_result = mysql_query($de_sql);
if(!$de_result) exit('fail&nbsp;'.mysql_error());
$de_array = mysql_fetch_array($de_result);
$departement=$arr_suzu[$de_array['daima']];

//region**************************************
$code_re=$de_array['id_region'];
$re_sql = "SELECT daima FROM region WHERE id_region = '$code_re' ";
$re_result = mysql_query($re_sql);
if(!$re_result) exit('fail&nbsp;'.mysql_error());
$re_array = mysql_fetch_array($re_result);
$region=$arr_suzu[$re_array['daima']];
//************************************

//查找同个departemnt的ville************************************************************
 
$cc=$code;
if($codepo=="201")$cc="2A";
if($codepo=="202")$cc="2B";
if($codepo=="20000")$cc="2A";
if($codepo=="20090")$cc="2A";
if($codepo=="20600")$cc="2B";
if($codepo=="20620")$cc="2B";



//ville*********************************************
if(is_numeric($ville)){
$cs_sql = "SELECT nom FROM ville WHERE id_ville = '$ville' ";
$cs_result = mysql_query($cs_sql);
if(!$cs_result) exit('fail&nbsp;'.mysql_error());
$cs_array = mysql_fetch_array($cs_result);
 $ville=$cs_array['nom'];
}

//******************************************************
$ville_sql = "SELECT * FROM ville WHERE id_departement like '$cc' ORDER BY nom LIMIT 40";
 
 
 
 
$ville_result = mysql_query($ville_sql);
if(!$ville_result) exit('fail&nbsp;'.mysql_error());


 
}else{
		//没有$_GET['v'] $_GET['c']时


}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" 
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta http-equiv="content-language"		content="fr"			/>
<meta name="copyright"		content="http://code-postal-fr.net" />
<meta name="classification"	content="code postal,codes postaux,courrier,poste" />

<meta name="content"		content="Code postal villes : cherchez le code postal d'une ville ou l'inverse parmi 36000 villes et trouvez aussi des suggestions de sites internet locaux (entreprises, loisirs, tourisme, etc.) ainsi qu'une carte de chaque ville." />
    
<meta name="description" content="Code postal villes : cherchez le code postal d'une ville ou l'inverse parmi 36000 villes et trouvez aussi des suggestions de sites internet locaux (entreprises, loisirs, tourisme, etc.) ainsi qu'une carte de chaque ville." />	 
	<meta name="expires"		content="never" />
      
<meta name="keywords" content="codespostaux, codes, postaux, code, postal, recherche, ville, france, rechercher, info, fr, departement, departements, gratuit, service, rechercher, codepostal, code-postal, codes-postaux, code postal, codes postaux, ville francaise" />

<title>
<?php if($ville)echo $ville," ";if($codepo)echo ' ',$codepo," ";if($departement)echo $departement," ";if($region)echo $region," ";?>
Code postal .  Tous les codes postaux de France</title>
 
<link href="css.css" rel="stylesheet" type="text/css" />
<link href="ville_show.css" rel="stylesheet" type="text/css" />


<style type="text/css">
 @import url("webfonts/Sansation_Regular/stylesheet.css");

</style>





</head>

<body>
<?php require("head.php");?>

<?php
if($ville&&$codepo){
	//有$_GET['v'] $_GET['c']时
?>
<br />
 
<div style="font-size:12px; padding:25px; color: #333 ">
<fieldset style=" padding:20px;border:1px solid #f00;" >
<legend>Cherchez le code postal d'une ville ou la ville pour un code postal</legend>
<br />
<br />

<form  id="form1" name="form1" method="post" action="recherche.php"  >
    <strong>Votre recherche :</strong> <input name="m"  class="input"    type="text"  value="<?php if($_POST['m']) echo $_POST['m']?>"  size="30"/> <input name="submit1" value="Chercher"  type="submit"    class="tijiaoanniuziti"/>  
    
    
 
     
  </form></fieldset>

  
 
  
 
</div>
<div id="ville-ex"  >

<div class="style2" style="padding:15px 40px 15px 40px ;"  >  
 <fieldset style=" padding:20px;border:1px solid #f00; " >
<legend>Les informations de</legend>
<br /><br />

 <?php
  //防止数据恶意注入
function check_input($value)
{
// 去除斜杠
if (get_magic_quotes_gpc())
  {
  $value = stripslashes($value);
  }
  
  $value = mysql_real_escape_string($value);
  
 
return $value;
}

$villev=check_input($ville);


  $code_sql = "SELECT  * FROM ville WHERE nom like '$villev' AND id_departement like '$cc' ORDER BY cp ";
  $code_result = mysql_query($code_sql);
if(!$code_result) exit('fail&nbsp;'.mysql_error());
while($code_array = mysql_fetch_array($code_result)){
	 if($code_array['nom_s'])$redirige= "(Redirigé depuis ".$code_array['nom_s'].")<br />";

	$code_arr[]=$code_array['cp'];
	$population=$code_array['population'];
    $arrondissement=$code_array['arrondissement'];
    $canton=$code_array['canton'];
    $superficie=$code_array['superficie'];
	$codecommune=$code_array['codecommune'];
    $id_ville=$code_array['id_ville'];
	$lat=$code_array['lat'];
	$lon=$code_array['lon'];

	}
	?>

<strong><span style="font-size: 30px;text-shadow:2px 1px 3px #999999;"  class="st"><?=$ville?> <?='(',$codepo,')';?></span></strong>
<br />
<br />
<div style="padding-left:10px;">



    
    <?php if($arrondissement||$canton||$population||$superficie){?>
    <span style="font-size:15px; font-family:'Times New Roman', Times, serif; color:#333 ">
    <?php if($redirige) echo $redirige;?>
<?=$ville?> est une commune du département des <strong><?=$departement?></strong>, dans la région de <strong><?=$region?></strong>, en France. <br /><br />
 
  Le code postal de <?=$ville?> est <?php
  
 	foreach($code_arr as $key =>$val){
		if($key==count($code_arr)-1){if($key!=0)echo " et ",$val;else echo $val;}
		elseif($key==count($code_arr)-2)echo $val;
		else {echo $val,", ";} 
		}
   
   
 ?>.</span>
 <?php }?>
 
 
 
 <?php  
 if($ville=="Paris")$id_ville='34491';
 if($ville=="Amiens")$id_ville='22739';
 if($ville=="Bordeaux")$id_ville='12028';
 if($ville=="Toulouse")$id_ville='11542';
 if($ville=="Lyon")$id_ville='34543';
  

 
 $plus_sql = "SELECT  content FROM ville_plus WHERE id_ville = '$id_ville' ";
  $plus_result = mysql_query($plus_sql);
if(!$plus_result) exit('fail&nbsp;'.mysql_error());
$plus_array = mysql_fetch_array($plus_result);

if($plus_array['content'])echo ' <span style="font-size:15px;'," font-family:'Times New Roman', Times, serif; ",'color:#333 "><br /><br />',nl2br($plus_array['content']),'<br /></span>';

?>
 
 <?php if($population||$arrondissement||$canton||$superficie){?><div style="padding:50px 10px 10px 0px ;">
 
 <table><tbody>
 
  <?php
}   
 	if($arrondissement)echo '<tr><td  class="text-shadow"  valign="top"  align="right" >Arrondissement  : </td><td valign="top" class="ttdd" > ',$arrondissement,"</td></tr>";
	if($canton)echo '<tr><td  class="text-shadow"  valign="top"  align="right" >Canton  : </td><td valign="top"  class="ttdd" >',$canton,"</td></tr>";
	if($population)echo '<tr><td  class="text-shadow"  valign="top"  align="right" >Population  : </td><td valign="top" class="ttdd"  >',number_format($population,0,""," ")," habitants(2011)</td></tr>";  
    if($superficie)echo '<tr><td  class="text-shadow"  valign="top"  align="right" >Superficie  : </td><td valign="top"  class="ttdd" >',$superficie,"  km2</td></tr>";
	if($population&&$superficie)echo '<tr><td  class="text-shadow"  valign="top"  align="right" >Densité : </td><td valign="top"  class="ttdd" >',number_format(round($population/str_replace(",",'.',$superficie)),0,""," ")," habitants/km2</td></tr>";
      
  
 
      if($population||$arrondissement||$canton||$superficie){  ?></td>
 
 </tbody></table>
 </div>
 <?php }?>
 </div>
 
<br /><br />

<a href="http://fr.wikipedia.org/wiki/<?=str_replace(' ','_',$ville)?>" class="ah2" target="_blank" >En savoir plus sur Wikipedia »
</a><!--http://www.insee.fr/fr/bases-de-donnees/esl/comparateur.asp? 以前的网址-->
<?php if($codecommune){?>
<br /><a href="http://www.insee.fr/fr/themes/comparateur.asp?codgeo=com-<?=$codecommune?>" class="ah2" target="_blank" >Voir les statistiques INSEE »</a><? }?> 
 
 <br /> <br />
 <script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<!-- zidong -->
<ins class="adsbygoogle"
     style="display:block"
     data-ad-client="ca-pub-6001819914727980"
     data-ad-slot="6625483771"
     data-ad-format="auto"></ins>
<script>
(adsbygoogle = window.adsbygoogle || []).push({});
</script><br />
<br />

 <fieldset style=" padding:20px;border:1px solid #f00;" >
<legend>Petites annonces de <?=$ville."(".$codepo.")"?></legend>
<div    style="padding:15px 15px 15px 50px; "   align="left">
<?php
$result_anoncev=file_get_contents("http://monpub.com/codepostal.php?codepo=$codepo");
 echo $result_anoncev;

?>

</div>
 </fieldset>

<br />
<br />
<div id='map' align="center">
 
  <iframe   class="map"  src="http://maps.google.fr/maps?f=q&q=<?=$ville?>+<?=$departement?>&z=12&output=embed&t=p" frameborder="0" scrolling="no" marginheight="0" marginwidth="0"   width="700px" height="500px" ></iframe>

</div>


<?php
//**********************************************************************************************************************
//附近城市
//****************************************************************************************************************************
define(EARTH_RADIUS, 6371);//地球半径，平均半径为6371km
 /**
 *计算某个经纬度的周围某段距离的正方形的四个点
 *
 *@param lon float 经度
 *@param lat float 纬度
 *@param distance float 该点所在圆的半径，该圆与此正方形内切，默认值为0.5千米
 *@return array 正方形的四个点的经纬度坐标
 */
 function returnSquarePoint($lon, $lat){
 $distance = 5;//默认值为0.5千米
    $dlon =  2 * asin(sin($distance / (2 * EARTH_RADIUS)) / cos(deg2rad($lat)));
    $dlon = rad2deg($dlon);
     
    $dlat = $distance/EARTH_RADIUS;
    $dlat = rad2deg($dlat);
     
    return array(
                'left-top'=>array('lat'=>$lat + $dlat,'lon'=>$lon-$dlon),
                'right-top'=>array('lat'=>$lat + $dlat, 'lon'=>$lon + $dlon),
                'left-bottom'=>array('lat'=>$lat - $dlat, 'lon'=>$lon - $dlon),
                'right-bottom'=>array('lat'=>$lat - $dlat, 'lon'=>$lon + $dlon)
                );
 }
//使用此函数计算得到结果后，带入sql查询。
$squares = returnSquarePoint($lon, $lat);
$rblat=$squares['right-bottom']['lat'];
$ltlat=$squares['left-top']['lat'];
$ltlon=$squares['left-top']['lon'];
$rblon=$squares['right-bottom']['lon'];
$info_sql = "select nom,cp,id_departement from ville where 1 AND lat<>0 AND lat > $rblat  AND lat < $ltlat  AND lon > $ltlon   AND lon < $rblon  ";

  $info_result = mysql_query($info_sql);
if(!$info_result) exit('fail&nbsp;'.mysql_error());
$chengshi[]=$ville;
$ss=0;

echo '<br /><strong><span style="font-size: 30px;text-shadow:2px 1px 3px #999999;"  class="st">Communes voisines :</span></strong><br /><br />';
 echo '<table align="center" style="width:90%"><tr>';

while($info_array = mysql_fetch_array($info_result)){$ss++;
	if($info_array['nom']==$ville||in_array($info_array['nom'],$chengshi))$ss=$ss-1;
	if($info_array['nom']!=$ville&&!in_array($info_array['nom'],$chengshi)){
	
	if($ss%3!=0){echo '<td valign="top"><a href="ville.php?v='.$info_array['nom'].'&c='.$info_array['cp'].'&d='.$info_array['id_departement'].'#ville-ex" class="a2" >'.$info_array['nom'].'</a></td>';}else{echo '<td valign="top"><a href="ville.php?v='.$info_array['nom'].'&c='.$info_array['cp'].'&d='.$info_array['id_departement'].'#ville-ex" class="a2" >'.$info_array['nom'].'</a></td></tr><tr>';}
	if(!in_array($info_array['nom'],$chengshi)) $chengshi[]= $info_array['nom'];

	}
	}

 	
	 

echo "</tr></table>";

//**********************************************************************************************************************
//****************************************************************************************************************************
?>

 </fieldset>

</div>
 


<?php if($ville!="Paris"){?> 
<div class="border-t" >
<br /><br />
 
 <fieldset style=" padding:20px;border:1px solid #f00;" >
<legend>Liste des villes du département <strong style="font-size:36px"><?=$departement?></strong> :</legend>
 
<div id="ville" style="padding:20px;">
<table><tbody><tr>
<?php
$s=0;
while($ville_array = mysql_fetch_array($ville_result)){
	if($ville_array['nom']!=$ville&&$ville_array['nom']){
	$s++;
	if($s%4==0)
	echo  '<td><span style="border-bottom:#CCCCCC 1px solid;"><a href="ville.php?v='.$ville_array['nom'].'&c='.$ville_array['cp'].'&d='.$code.'#ville-ex" class="a3" >',$ville_array['nom'],'</a></span></td></tr><tr>';
 else   echo  '<td><span style="border-bottom:#CCCCCC 1px solid;"><a href="ville.php?v='.$ville_array['nom'].'&c='.$ville_array['cp'].'&d='.$code.'#ville-ex" class="a3" >',$ville_array['nom'],'</a></span></td>';
	}
  
	 
	 
	 
	  }?>
<tr><td>......</td></tr>
 </tr></tbody></table></div>

 </fieldset>
</div>
<?php }?>

</div>
<?php 

}else{
	
	$pasdeadfoot='1';//不要foot里的广告
		//没有$_GET['v'] $_GET['c']时
?>

 <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.4/jquery.min.js"></script>
 <script>
$(function() {
 var i=-1;

 
$("#k").keyup(function(event){
var keycd=event.which;

	if(keycd!=38&&keycd!=39&&keycd!=40&&keycd!=37&&keycd!=13){
	
	
	 
var url = "ville_show.php";
var k=$('#k').val();

if(k.length>=2){
$.ajax({
type: "post",
url: url,
dataType: "json",
data: "k="+k,
success: function(msg){

var tishi=msg.k;
$('#tishi').show();
$('#tishi').html(tishi);



 
 
 
}
	});
	
}else{$('#tishi').html();$('#tishi').hide();
}
 	
	
	
	}else {
		
//*******************************************************************************************
 var x=document.getElementById("tishi");
 var y=x.getElementsByClassName("a1");

 

if(keycd==40){
  	
if(i==y.length-1)i=0;else i=i+1;

 	y[i].style.background='#ccc';
  		
		
	for(var s=0; s<y.length;s++){
		if(s!=i)y[s].style.background='#fff';}
	 
	
 	 }
	 


 if(keycd==38){
	 
	 if(i==0)i=y.length-1;else i=i-1;

 	y[i].style.background='#ccc';
  		
		
		
	for(var s=0; s<y.length;s++){
		if(s!=i)y[s].style.background='#fff';}
			 
	  
  	 }	 
	 
	 
	   if(keycd==13)y[i].click();

		  
		   
	 
 
   
 
 
 //*****************************************************************
 }
	
	
	
	
	});
	
	});
</script>
<div id='ville-nonex'  style="padding:15px 15px 15px 25px;" class="style2">
 <strong style=" font-family: 'Trebuchet MS', Arial, Helvetica, sans-serif; font-size:36px">Recherche par Ville</strong><br />
 <br />
 <fieldset style=" padding:20px;border:1px solid #f00;" >
<legend><strong>Saisir au moins 2 lettres de nom de la ville : </strong></legend>

<span   class="ville" ><input name="k"  type="text"  class="input" id="k"   size="30"   /><span id="tishi" ></span>
    </span>  
  </fieldset>
</div>





<br />
<br />
<br />
 
 
 











<?php }?>
 <br />
<br /> <br />


<?php require("foot.php");?>
</body>
</html>