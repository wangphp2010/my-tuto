<?php
require('commun/codeconn.php');
require('commun/codeca.php');



 //查找同个departemnt的ville************************************************************

$co=$_GET['d'];

$ville_sql = "SELECT * FROM ville WHERE id_departement like '$co' ORDER BY population DESC LIMIT 40 ";
$ville_result = mysql_query($ville_sql);
if(!$ville_result) exit('fail&nbsp;'.mysql_error());


//departement*****************************************************************************************
$de_sql = "SELECT daima FROM departement WHERE code like '$co' ";
$de_result = mysql_query($de_sql);
if(!$de_result) exit('fail&nbsp;'.mysql_error());
$de_array = mysql_fetch_array($de_result);
$departement=$arr_suzu[$de_array['daima']];

 
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" 
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta http-equiv="content-language"		content="fr"			/>
<meta name="copyright"		content="http://code-postal-fr.net" />
<meta name="classification"	content="code postal,codes postaux,courrier,poste" />

<meta name="content"		content="Code postal villes : cherchez le code postal d'une ville ou l'inverse parmi 36000 villes et trouvez aussi des suggestions de sites internet locaux (entreprises, loisirs, tourisme, etc.) ainsi qu'une carte de chaque ville." />
    
<meta name="description" content="Code postal villes : cherchez le code postal d'une ville ou l'inverse parmi 36000 villes et trouvez aussi des suggestions de sites internet locaux (entreprises, loisirs, tourisme, etc.) ainsi qu'une carte de chaque ville." />	 
	<meta name="expires"		content="never" />
      
<meta name="keywords" content="codespostaux, codes, postaux, code, postal, recherche, ville, france, rechercher, info, fr, departement, departements, gratuit, service, rechercher, codepostal, code-postal, codes-postaux, code postal, codes postaux, ville francaise" />
    
<title>Code postal . 
<?=$departement?> 
Tous les codes postaux de France</title>
 
<link href="css.css" rel="stylesheet" type="text/css" />
<style type="text/css">
 @import url("webfonts/Sansation_Regular/stylesheet.css");

</style>
 </head>

<body>
<?php require("head.php");?><br /><br />

<?php
if($co){?>
<div  >
<br />
 
 <fieldset style=" padding:20px;border:1px solid #f00;" >
<legend>Liste des villes du département <strong style="font-size:36px">(<?=$departement?>)</strong></legend>
<div id="ville" style="padding:20px;" class="style3">
<table cellspacing="2"><tbody><tr>
<?php



$s=0;
while($ville_array = mysql_fetch_array($ville_result)){
	if($ville_array['nom']){
		$ville_sp='';
		 if($ville_array['nom']=="Paris"||$ville_array['nom']=="Marseille"||$ville_array['nom']=="Lyon")$ville_sp="-".$ville_array['cp'];

	$s++;
	if($s%4==0)
	echo  '<td><span style="border-bottom:#CCCCCC 1px solid;"><a href="ville.php?v='.$ville_array['nom'].'&c='.$ville_array['cp'].'&d='.$co.'#ville-ex" class="a3" >',$ville_array['nom'],$ville_sp,'</a></span></td></tr><tr>';
 else   echo  '<td><span style="border-bottom:#CCCCCC 1px solid;"><a href="ville.php?v='.$ville_array['nom'].'&c='.$ville_array['cp'].'&d='.$co.'#ville-ex" class="a3" >',$ville_array['nom'],$ville_sp,'</a></span></td>';
	 
  
	 
	}
	 
	  }?>

 </tr>      <tr><td>......</td></tr>
</tbody></table></div>
 
<br />
<br />
<div id='map' align="center">
  <iframe   class="map" marginheight="0" marginwidth="0" src="https://maps.google.fr/maps?q=<?=$departement?>&ie=UTF-8&ei=fQbQUoisIauY0QWJk4HACQ&sqi=2&ved=0CAgQ_AUoAg&output=embed" frameborder="0" height="500" scrolling="no" width="700"></iframe>
</div>
 </fieldset>
</div><br />
<br />

<?php }?>
 
<div class=" style3"> 
 <fieldset style=" padding:20px;border:1px solid #f00;" >
<legend><strong style=" font-size:30px">Recherche par Département </strong>  </legend>
  <table cellspacing="2"    align="center" ><tbody>
    <tr>
      <td width="25%" valign="top">
        
  <a href='/departement.php?d=01' class="a3" >(01) - Ain</a><br />
  <a href='/departement.php?d=02' class="a3" >(02) - Aisne</a><br />
  <a href='/departement.php?d=03' class="a3" >(03) - Allier</a><br />
  <a href='/departement.php?d=04' class="a3" >(04) - Alpes-de-Haute-Provence</a><br />
  <a href='/departement.php?d=05' class="a3" >(05) - Hautes-Alpes</a><br />
  <a href='/departement.php?d=06' class="a3" >(06) - Alpes-Maritimes</a><br />
  <a href='/departement.php?d=07' class="a3" >(07) - Ardèche</a><br />
  <a href='/departement.php?d=08' class="a3" >(08) - Ardennes</a><br />
  <a href='/departement.php?d=09' class="a3" >(09) - Ariège</a><br />
  <a href='/departement.php?d=10' class="a3" >(10) - Aube</a><br />
  <a href='/departement.php?d=11' class="a3" >(11) - Aude</a><br />
  <a href='/departement.php?d=12' class="a3" >(12) - Aveyron</a><br />
  <a href='/departement.php?d=13' class="a3" >(13) - Bouches-du-Rhône</a><br />
  <a href='/departement.php?d=14' class="a3" >(14) - Calvados</a><br />
  <a href='/departement.php?d=15' class="a3" >(15) - Cantal</a><br />
  <a href='/departement.php?d=16' class="a3" >(16) - Charente</a><br />
  <a href='/departement.php?d=17' class="a3" >(17) - Charente-Maritime</a><br />
  <a href='/departement.php?d=18' class="a3" >(18) - Cher</a><br />
  <a href='/departement.php?d=19' class="a3" >(19) - Corrèze</a><br />
  <a href='/departement.php?d=2A' class="a3" >(2A) - Corse-du-sud</a><br />
  <a href='/departement.php?d=2B' class="a3" >(2B) - Haute-corse</a><br />
  <a href='/departement.php?d=21' class="a3" >(21) - Côte-d'Or</a><br />
  <a href='/departement.php?d=22' class="a3" >(22) - Côtes-d'Armor</a><br />
  <a href='/departement.php?d=23' class="a3" >(23) - Creuse</a><br />
  <a href='/departement.php?d=24' class="a3" >(24) - Dordogne</a><br />
  <a href='/departement.php?d=25' class="a3" >(25) - Doubs</a><br />
     
</td>
  
  <td width='25%' valign="top">
  <a href='/departement.php?d=26' class="a3" >(26) - Drôme</a><br />
  <a href='/departement.php?d=27' class="a3" >(27) - Eure</a><br />
  <a href='/departement.php?d=28' class="a3" >(28) - Eure-et-Loir</a><br />
  <a href='/departement.php?d=29' class="a3" >(29) - Finistère</a><br />
  <a href='/departement.php?d=30' class="a3" >(30) - Gard</a><br />
  <a href='/departement.php?d=31' class="a3" >(31) - Haute-Garonne</a><br />
  <a href='/departement.php?d=32' class="a3" >(32) - Gers</a><br />
  <a href='/departement.php?d=33' class="a3" >(33) - Gironde</a><br />
  <a href='/departement.php?d=34' class="a3" >(34) - Hérault</a><br />
  <a href='/departement.php?d=35' class="a3" >(35) - Ille-et-Vilaine</a><br />
  <a href='/departement.php?d=36' class="a3" >(36) - Indre</a><br />
  <a href='/departement.php?d=37' class="a3" >(37) - Indre-et-Loire</a><br />
  <a href='/departement.php?d=38' class="a3" >(38) - Isère</a><br />
  <a href='/departement.php?d=39' class="a3" >(39) - Jura</a><br />
  <a href='/departement.php?d=40' class="a3" >(40) - Landes</a><br />
  <a href='/departement.php?d=41' class="a3" >(41) - Loir-et-Cher</a><br />
  <a href='/departement.php?d=42' class="a3" >(42) - Loire</a><br />
  <a href='/departement.php?d=43' class="a3" >(43) - Haute-Loire</a><br />
  <a href='/departement.php?d=44' class="a3" >(44) - Loire-Atlantique</a><br />
  <a href='/departement.php?d=45' class="a3" >(45) - Loiret</a><br />
  <a href='/departement.php?d=46' class="a3" >(46) - Lot</a><br />
  <a href='/departement.php?d=47' class="a3" >(47) - Lot-et-Garonne</a><br />
  <a href='/departement.php?d=48' class="a3" >(48) - Lozère</a><br />
  <a href='/departement.php?d=49' class="a3" >(49) - Maine-et-Loire</a><br />
  <a href='/departement.php?d=50' class="a3" >(50) - Manche</a><br />
  <a href='/departement.php?d=51' class="a3" >(51) - Marne</a><br />
  <a href='/departement.php?d=52' class="a3" >(52) - Haute-Marne</a><br />




  </td>
  
  <td width='25%' valign="top">
  <a href='/departement.php?d=53' class="a3" >(53) - Mayenne</a><br />
  <a href='/departement.php?d=54' class="a3" >(54) - Meurthe-et-Moselle</a><br />
  <a href='/departement.php?d=55' class="a3" >(55) - Meuse</a><br />
  <a href='/departement.php?d=56' class="a3" >(56) - Morbihan</a><br />
  <a href='/departement.php?d=57' class="a3" >(57) - Moselle</a><br />
  <a href='/departement.php?d=58' class="a3" >(58) - Nièvre</a><br />
  <a href='/departement.php?d=59' class="a3" >(59) - Nord</a><br />
  <a href='/departement.php?d=60' class="a3" >(60) - Oise</a><br />
  <a href='/departement.php?d=61' class="a3" >(61) - Orne</a><br />
  <a href='/departement.php?d=62' class="a3" >(62) - Pas-de-Calais</a><br />
  <a href='/departement.php?d=63' class="a3" >(63) - Puy-de-Dôme</a><br />
  <a href='/departement.php?d=64' class="a3" >(64) - Pyrénées-Atlantiques</a><br />
  <a href='/departement.php?d=65' class="a3" >(65) - Hautes-Pyrénées</a><br />
  <a href='/departement.php?d=66' class="a3" >(66) - Pyrénées-Orientales</a><br />
  <a href='/departement.php?d=67' class="a3" >(67) - Bas-Rhin</a><br />
  <a href='/departement.php?d=68' class="a3" >(68) - Haut-Rhin</a><br />
  <a href='/departement.php?d=69' class="a3" >(69) - Rhône</a><br />
  <a href='/departement.php?d=70' class="a3" >(70) - Haute-Saône</a><br />
  <a href='/departement.php?d=71' class="a3" >(71) - Saône-et-Loire</a><br />
  <a href='/departement.php?d=72' class="a3" >(72) - Sarthe</a><br />
  <a href='/departement.php?d=73' class="a3" >(73) - Savoie</a><br />
  <a href='/departement.php?d=74' class="a3" >(74) - Haute-Savoie</a><br />
  <a href='/departement.php?d=75' class="a3" >(75) - Paris</a><br />
  <a href='/departement.php?d=76' class="a3" >(76) - Seine-Maritime</a><br />
  <a href='/departement.php?d=77' class="a3" >(77) - Seine-et-Marne</a><br />
  <a href='/departement.php?d=78' class="a3" >(78) - Yvelines</a><br />
  <a href='/departement.php?d=79' class="a3" >(79) - Deux-Sèvres</a><br />
 </td>
  
  <td width='25%' valign="top">
  <a href='/departement.php?d=80' class="a3" >(80) - Somme</a><br />
  <a href='/departement.php?d=81' class="a3" >(81) - Tarn</a><br />
  <a href='/departement.php?d=82' class="a3" >(82) - Tarn-et-Garonne</a><br />
  <a href='/departement.php?d=83' class="a3" >(83) - Var</a><br />
  <a href='/departement.php?d=84' class="a3" >(84) - Vaucluse</a><br />
  <a href='/departement.php?d=85' class="a3" >(85) - Vendée</a><br />
  <a href='/departement.php?d=86' class="a3" >(86) - Vienne</a><br />
  <a href='/departement.php?d=87' class="a3" >(87) - Haute-Vienne</a><br />
  <a href='/departement.php?d=88' class="a3" >(88) - Vosges</a><br />
  <a href='/departement.php?d=89' class="a3" >(89) - Yonne</a><br />
  <a href='/departement.php?d=90' class="a3" >(90) - Territoire de Belfort</a><br />
  <a href='/departement.php?d=91' class="a3" >(91) - Essonne</a><br />
  <a href='/departement.php?d=92' class="a3" >(92) - Hauts-de-Seine</a><br />
  <a href='/departement.php?d=93' class="a3" >(93) - Seine-Saint-Denis</a><br />
  <a href='/departement.php?d=94' class="a3" >(94) - Val-de-Marne</a><br />
  <a href='/departement.php?d=95' class="a3" >(95) - Val-d'Oise</a><br />


  <a href='/departement.php?d=971' class="a3" >(971) - Guadeloupe</a><br />
  <a href='/departement.php?d=972' class="a3" >(972) - Martinique</a><br />
  <a href='/departement.php?d=973' class="a3" >(973) - Guyane</a><br />
  <a href='/departement.php?d=974' class="a3" >(974) - Réunion</a><br />
  <a href='/departement.php?d=975' class="a3" >(975) - Saint-Pierre et Miquelon</a><br />
  <a href='/departement.php?d=976' class="a3" >(976) - Mayotte</a><br />
  <a href='/departement.php?d=986' class="a3" >(986) - Wallis-et-Futuna</a><br />
  <a href='/departement.php?d=987' class="a3" >(987) - Polynésie française</a><br />
  <a href='/departement.php?d=988' class="a3" >(988) - Nouvelle-Calédonie</a><br />
  
    
    </td>
      </tr>
      </tbody>
    </table>

</fieldset>

</div>

<br />
<fieldset style=" padding:20px;border:1px solid #f00;" >
<legend>Petites annonces de <?=$departement?></legend>
<div    style="padding:15px 15px 15px 50px; "   align="left">
<?php
 $result_anoncev=file_get_contents("http://monpub.com/codepostal.php?codepo=$co");
 echo $result_anoncev;
?>

</div>
 </fieldset><br />




 
 <br />
<br />
<?php require("foot.php");?>
</body>
</html>